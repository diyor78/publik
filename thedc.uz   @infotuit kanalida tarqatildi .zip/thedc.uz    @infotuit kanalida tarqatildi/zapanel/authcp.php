<?php
$title = 'Вход на Управление сайтом';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Вход на Управление сайтом</div>';
$stmtcp = $connect->prepare("select count(*) from `users` where `access_cp` = ?");
$stmtcp->execute(array($user['id']));
$numcp = $stmtcp->fetchColumn();
if ($numcp > 0) {
$stmtcpd = $connect->prepare("select * from `users` where `access_cp` = ? limit 1");
$stmtcpd->execute(array($user['id']));
$cpd = $stmtcpd->fetch(PDO::FETCH_LAZY);

echo '<div class="menu">&bull; <a href="/authcp/ok"> Вход на свои Управление сайтом</a></div>';

$asset = $connect->query("select * from `users` where `access_cp` = '$user->id'")->fetchAll();
foreach ($asset as $cpaa) {
    echo '<div class="menu">&bull; <a href="/authcp/access/'.$cpaa['id'].'"> Вход на <font color="red">'.$cpaa['login'].'</font> Управление сайтом</a></div>';
}

}elseif (empty($_GET['accesscp'])){
    $kauth = md5(md5(time()));
    $auth = $connect->prepare("insert into `mgr_sessions` set `key_auth` = ?, `id_user` = ?, `time` = ?, `ip` = ?, `ua` = ?, `activ` = ?, `id_enter` = ?");
    if ($auth->execute(array($kauth, $user['id'], time(), $ip, $ua, 1, $user['id']))){
        header('Location: https://mgr.thedc.uz/authcp?key='.$kauth.'&id_user='.$user['id']);
    }
}

if ($_GET['mycp'] == 'ok') {
    $kauth = md5(md5(time()));
    $auth = $connect->prepare("insert into `mgr_sessions` set `key_auth` = ?, `id_user` = ?, `time` = ?, `ip` = ?, `ua` = ?, `activ` = ?, `id_enter` = ?");
    if ($auth->execute(array($kauth, $user['id'], time(), $ip, $ua, 1, $user['id']))){
    header('Location: https://mgr.thedc.uz/authcp?key='.$kauth.'&id_user='.$user['id']);
    }
}
if (isset($_GET['accesscp'])) {
    $acid = (int) $_GET['accesscp'];
    $debas = $connect->prepare("select count(*) from `users` where `access_cp` = ? and `id` = ?");
    $debas->execute(array($user['id'], $acid));
    $deb = $debas->fetchColumn();
    if ($deb) {
    $kauth = md5(md5(time()));
    $auth = $connect->prepare("insert into `mgr_sessions` set `key_auth` = ?, `id_user` = ?, `time` = ?, `ip` = ?, `ua` = ?, `activ` = ?, `id_enter` = ?");
    if ($auth->execute(array($kauth, $acid, time(), $ip, $ua, 1, $user['id']))){
    header('Location: https://mgr.thedc.uz/authcp?key='.$kauth.'&id_user='.$acid);
    }else{
        echo '<div class="err">Пожалуйста напишите этот ошибка на Создатель!</div>';
    }
    }else{
        echo '<div class="err">Ой! ты взломал мой биллинг :)  (Powered By UzMaxBoy)</div>';
    }
}

} else {header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
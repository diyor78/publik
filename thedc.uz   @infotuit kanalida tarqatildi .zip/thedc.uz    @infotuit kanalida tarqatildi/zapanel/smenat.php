<?php
$title='Смена тарифа';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
    $ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
    $ontarif->execute(array($user['id_tarif']));
    $ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
    $server = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($ustarif[id_server]))."'");
    $server = $server->fetch(PDO::FETCH_LAZY);
    $srvid = $server['id'];
echo '<div class="title">Смена тарифа</div>';
if ($user['accesstos'] == 2){
$colls = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `activ`='1' AND `id_server` = '$srvid' AND `id` = '$id'");
// Yangi tarif
$ontarifs = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
$ontarifs->execute(array($id));
$ustarifs = $ontarifs->fetch(PDO::FETCH_LAZY);
$colls = $colls->fetchColumn();
if ($colls > 0){
if ($user[activ]==1 || $user[activ]==2 || $user[activ]==3) {
if ($user[id_tarif] != $id) {
if ($user[activ]==1) {
$connect->exec("UPDATE `users` SET `id_tarif` = '$id' WHERE `id` = '".$user['id']."' LIMIT 1");
echo '<div class="menu"><center><font color="gren">Тариф успешно сменен!</font></center></div>';
echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}else{
if ($user['money'] >= $ustarifs['price_day']) {
$preset=$ustarifs[template];
$qas=array("ssl"=>array("verify_peer"=>false,"verify_peer_name"=>false,),);
$reguserisp = file_get_contents("https://91.134.253.116:1500/ispmgr?func=user.edit&owner=uzxost&out=xml&authinfo=".$server[login].":".$server[pass]."&elid=".$user[isp_login]."&preset=".$preset."&sok=yes", false, stream_context_create($qas));
if (preg_match('<ok/>',$reguserisp)) {
$cena = $ustarifs['price_day'];
$connect->exec("UPDATE `users` SET `money` = `money` - '$cena', `id_tarif` = '$id' WHERE `id` = '".$user['id']."' LIMIT 1");
$connect->exec("INSERT INTO `logs_money` SET `id_user` = '".$user['id']."', `type` = 'minus', `count` = '".$cena."', `action` = 'Для смена тариф на: ".$ustarifs[name]."', `time` = '".$time."'");    
echo '<div class="menu"><center><font color="gren">Тариф успешно сменен!</font></center></div>';
echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}else{
    //echo print_r($reguserisp);
    echo '<div class="menu"><center><font color="red">У вас много ресурс! чем новый тариф!!!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
}else {
    echo '<div class="menu"><center><font color="red">У вас недостаточно средств для смены тарифа!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
}
}else{
    echo '<div class="menu"><center><font color="red">Вы используете данный тариф!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
}else {
    echo '<div class="menu"><center><font color="red">Вам нельзя сменить тариф!!!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
}else {
    echo '<div class="menu"><center><font color="red">Не возможно перейти на тариф!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
}else{
    echo '<div class="menu"><center><font color="red">У вас нет доступ к смена тариф!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
} else {
header('Location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
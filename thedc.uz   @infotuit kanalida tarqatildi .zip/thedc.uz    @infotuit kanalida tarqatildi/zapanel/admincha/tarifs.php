<?php

$title = 'Хостинг || Тарифы';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if ($adm_id == 5) {

if(isset($_GET['edit']))
{
    $q1 = $connect->prepare("SELECT * FROM `tarifs_hosting` WHERE `id` = ? LIMIT 1");
$q1->execute(array(val($_GET['edit'])));
}
if(isset($_GET['del']))
{
    $q2 = $connect->prepare("SELECT * FROM `tarifs_hosting` WHERE `id` = ? LIMIT 1");
$q2->execute(array(val($_GET['del'])));
}
// редактирование тарифа
if(isset($_GET['edit']) && $q1->rowCount()>0)
{
$hosting = $connect->prepare("SELECT * FROM `tarifs_hosting` WHERE `id` = ?");
$hosting->execute(array(val($_GET['edit'])));
$hosting = $hosting->fetch(PDO::FETCH_LAZY);
if(isset($_POST['submit']))
{
$name = filter($_POST['name']);
$template = filter($_POST['template']);
$panel = filter($_POST['panel']);
$hdd = filter($_POST['hdd']);
$trafic = filter($_POST['trafic']);
$domain = filter($_POST['domain']);
$ftp = filter($_POST['ftp']);
$mail = filter($_POST['mail']);
$mysql = filter($_POST['mysql']);
$ram = filter($_POST['ram']);
$cpu = filter($_POST['cpu']);
$cpu_user = filter($_POST['cpu_user']);
$io = filter($_POST['io']);
$activ = abs(intval($_POST['activ']));
$server = $connect->prepare("SELECT * FROM `servers` WHERE `id` = ?");
$server->execute([$_POST['server']]);
$server = $server->fetch(PDO::FETCH_OBJ);
$price_day = filter($_POST['price_day']);
$price_month = filter($_POST['price_month']);
$price_year = filter($_POST['price_year']);

$resa = $connect->prepare("UPDATE `tarifs_hosting` SET `name` = ?, `template` = ?, `panel` = ?, `hdd` = ?, `trafic` = ?, `domain` = ?, `ftp` = ?, `mail` = ?, `mysql` = ?, `ram` = ?, `cpu` = ?, `cpu_user` = ?, `io` = ?, `activ` = ?, `id_server` = ?, `price_day` = ?, `price_month` = ?, `price_year` = ? WHERE `id` = ?");
$resa->execute(array($name,$template,$panel,$hdd,$trafic,$domain,$ftp,$mail,$mysql,$ram,$cpu,$cpu_user,$io,$activ,$server->id,$price_day,$price_month,$price_year,$hosting->id));
header('Location:/adm/tarifs');
}
else
{
echo '<div class = "title">Изменение тарифа</div>';
echo '<div class="menu">';
echo '<form method="post">';
echo '<font color = "black">Название тарифа : <br /><input type="text" name="name" value="'.$hosting->name.'" required/><br/>';
echo 'Название шаблона ISP  : <br /><input type="text" name="template" value="'.$hosting->template.'" required/><br/>';
echo 'Панель управления   : <br /><input type="text" name="panel" value="'.$hosting->panel.'" required/><br/>';
echo 'Место на диске : <br /> <input type="text" name="hdd" value="'.$hosting->hdd.'" required/><br/>';
echo 'Трафик : <br /> <input type="text" name="trafic" value="'.$hosting->trafic.'" required/><br/>';
echo 'Доменов/поддоменов : <br /> <input type="text" name="domain" value="'.$hosting->domain.'" required/><br/>';
echo 'FTP-доступ : <br /> <input type="text" name="ftp" value="'.$hosting->ftp.'" required/><br/>';
echo 'POP3-ящики : <br /> <input type="text" name="mail" value="'.$hosting->mail.'" required/><br/>';
echo 'Базы данных : <br /> <input type="text" name="mysql" value="'.$hosting->mysql.'" required/><br/>';
echo 'RAM (на 1 процесс) : <br /> <input type="text" name="ram" value="'.$hosting->ram.'" required/><br/>';
echo 'CPU (на 1 процесс) : <br /> <input type="text" name="cpu" value="'.$hosting->cpu.'" required/><br/>';
echo 'CPU (на аккаунт от ядра) : <br /> <input type="text" name="cpu_user" value="'.$hosting->cpu_user.'" required/><br/>';
echo 'I/O (нагрузка на диск) : <br /> <input type="text" name="io" value="'.$hosting->io.'" required/><br/>';
echo 'Активен : <br /> <select name="activ">
<option value="0" '.($hosting->activ==0?'selected':'').'>НЕТ</option>
<option value="1" '.($hosting->activ==1?'selected':'').'>ДА</option>
</select></br>';
echo 'Сервер : <br /> <select name="server">';
$q = $connect->query("SELECT * FROM `servers` ORDER BY `id` DESC");
while ($server = $q->fetch(PDO::FETCH_LAZY))
{
echo '<option value="'.$server->id.' '.($hosting->id_server==$server->id?'selected':'').'">'.$server->ip.'</option>';
}
echo '</select></br>';
echo 'Цена в День : <br /><input type="text" name="price_day" value="'.$hosting->price_day.'" required/><br/>';
echo 'Цена в месяц : <br /><input type="text" name="price_month" value="'.$hosting->price_month.'" required/><br/>';
echo 'Цена в год : <br /><input type="text" name="price_year" value="'.$hosting->price_year.'" required/><br/>';

echo '<br/></font><input class="btn btn-default" type="submit" name="submit" value="Изменить"/>';
echo '<div align="right"><a href="/adm/tarifs?del='.$hosting->id.'">Удалить тариф</a></div>';
echo '</div>';
}
}
// удаление тарифа
elseif(isset($_GET['del']) && $q2->rowCount()>0)
{
$hosting = $connect->prepare("SELECT * FROM `tarifs_hosting` WHERE `id` = ?");
$hosting->execute(array(val($_GET['del'])));
$hosting = $hosting->fetch(PDO::FETCH_LAZY);
if(isset($_GET['save']))
{
if(isset($_POST['yes']))
{
$q3 = $connect->prepare("SELECT * FROM `orders_hosting` WHERE `id_tarif` = ? LIMIT 1");
$q3->execute(array($hosting->id));
if($q3->rowCount()==0)
{
$connect->query("DELETE FROM `tarifs_hosting` WHERE `id` = '". $hosting->id ."'");
header('Location:/adm/tarifs');
}
else
{
header( 'Refresh: 5; url=/adm/tarifs' );
echo '<div class="err">Данный тариф не может быть удален!</div>';
}
}
else header('Location:/adm/tarifs');
}
else
{
echo '<div class="title">Удаление тарифа</div>';
echo '<div class="menu">';
echo '<form method="post" action="/adm/tarifs?del='.$hosting->id.'&save">';
echo 'Удалить тариф '.$hosting->name.'?<br/>';
echo '<br/><input class="btn btn-default" type="submit" name="no" value="Нет, оставить"/>  <input class="btn btn-default" type="submit" name="yes" value="Да, удалить"/>';
echo '</div>';
}
}
//  создание тарифа
elseif(isset($_GET['add']))
{
if(isset($_GET['save']))
{
$name = filter($_POST['name']);
$template = filter($_POST['template']);
$panel = filter($_POST['panel']);
$hdd = filter($_POST['hdd']);
$trafic = filter($_POST['trafic']);
$domain = filter($_POST['domain']);
$ftp = filter($_POST['ftp']);
$mail = filter($_POST['mail']);
$mysql = filter($_POST['mysql']);
$ram = filter($_POST['ram']);
$cpu = filter($_POST['cpu']);
$cpu_user = filter($_POST['cpu_user']);
$io = filter($_POST['io']);
$activ = abs(intval($_POST['activ']));
$server = $connect->prepare("SELECT * FROM `servers` WHERE `id` = ?");
$server->execute([$_POST['server']]);
$server = $server->fetch(PDO::FETCH_LAZY);
$price_day = filter($_POST['price_day']);
$price_month = filter($_POST['price_month']);
$price_year = filter($_POST['price_year']);

$resb = $connect->prepare("INSERT INTO `tarifs_hosting` SET `name` = ?, `template` = ?, `panel` = ?, `hdd` = ?, `trafic` = ?, `domain` = ?, `ftp` = ?, `mail` = ?, `mysql` = ?, `ram` = ?, `cpu` = ?, `cpu_user` = ?, `io` = ?, `activ` = ?, `id_server` = ?, `price_day` = ?, `price_month` = ?, `price_year` = ?");
$resb->execute(array($name,$template,$panel,$hdd,$trafic,$domain,$ftp,$mail,$mysql,$ram,$cpu,$cpu_user,$io,$activ,$server->id,$price_day,$price_month,$price_year));
header('Location:/adm/tarifs');

}
else
{
echo '<div class="title">Новый тариф</div>';
echo '<div class="menu">';
echo '<form method="post" action="/adm/tarifs?add&save">';
echo 'Название тарифа : <br /><input type="text" name="name" required/><br/>';
echo 'Название шаблона ISP: <br /> <input type="text" name="template" required/><br/>';
echo 'Панель управления : <br /> <input type="text" name="panel" required/><br/>';
echo 'Место на диске : <br /> <input type="text" name="hdd" required/><br/>';
echo 'Трафик : <br /> <input type="text" name="trafic" required/><br/>';
echo 'Доменов/поддоменов : <br /> <input type="text" name="domain" required/><br/>';
echo 'FTP-доступ : <br /> <input type="text" name="ftp" required/><br/>';
echo 'POP3-ящики : <br /> <input type="text" name="mail" required/><br/>';
echo 'Базы данных : <br /> <input type="text" name="mysql" required/><br/>';
echo 'RAM (на 1 процесс) : <br /> <input type="text" name="ram" required/><br/>';
echo 'CPU (на 1 процесс) : <br /> <input type="text" name="cpu" required/><br/>';
echo 'CPU (на аккаунт от ядра) : <br /> <input type="text" name="cpu_user" required/><br/>';
echo 'I/O (нагрузка на диск) : <br /> <input type="text" name="io" required/><br/>';
echo 'Активен : <br /> <select name="activ">
<option value="0">НЕТ</option>
<option value="1">ДА</option>
</select></br>';
echo 'Сервер : <br /> <select name="server">';
$q = $connect->query("SELECT * FROM `servers` ORDER BY `id` DESC");
while ($server = $q->fetch(PDO::FETCH_LAZY))
{
echo '<option value="'.$server->id.'">'.$server->ip.'</option>';
}
echo '</select></br>';
echo 'Цена в День : <br /><input type="text" name="price_day" required/><br/>';
echo 'Цена в месяц : <br /><input type="text" name="price_month" required/><br/>';
echo 'Цена в год : <br /><input type="text" name="price_year" required/><br/>';

echo '<br/><input class="btn btn-default" type="submit" name="submit" value="Создать"/>';
echo '</div>';
}
}
// просмотр тарифов
else
{
$k_post = $connect->query("SELECT * FROM `tarifs_hosting`");
$k_post = $k_post->rowCount();
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;
if ($k_post==0) {
    echo '<div class="menu"><center><font color="red">Нет тарифы</font></center></div>';
}
$q = $connect->query("SELECT * FROM `tarifs_hosting` ORDER BY `sort` ASC LIMIT $start, 10");
while ($tarif = $q->fetch(PDO::FETCH_LAZY))
{
echo '<div class="title">Тариф: '.$tarif->name.' </div>';
echo '<div class="menu">';
$hos = $connect->prepare("SELECT * FROM `users` WHERE `activ` = '2' AND`id_tarif` = ?");
$hos->execute(array($tarif->id));
$hos = $hos->rowCount();
echo '<font color = "#344d61">Заказано-('.$hos.')'.($tarif->activ==1?' [<font color="gren">Активен</font>]':'[<font color="red">Отключен</font>]').'<br/><br/></font>';
echo '<a href="/adm/tarifs?edit='.$tarif->id.'">Изменить</a>';
echo '</div>';
}

echo '<div class="menu">&bull;<a href="/adm/tarifs?add""> Добавить</a></div>';
echo '<div class="menu">&bull;<a href="/adm"> Назад</a></div>';
if ($k_page  > 1)str('/adm/tarifs?', $k_page, $page);
}
} else {
header ('location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
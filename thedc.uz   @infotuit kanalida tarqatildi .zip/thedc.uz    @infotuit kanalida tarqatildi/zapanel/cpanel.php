<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
switch($act) {
default:
$auth_succ = $connect->query("SELECT COUNT(*) FROM `authlog` WHERE `uid` = '$user->id' AND `status` = '1'")->fetchColumn();
$auth_fail = $connect->query("SELECT COUNT(*) FROM `authlog` WHERE `uid` = '$user->id' AND `status` = '0'")->fetchColumn();
$or_host = $connect->query("SELECT COUNT(*) FROM `orders_hosting` WHERE `id_user` = '$user->id'")->fetchColumn();
$log_monp = $connect->query("SELECT COUNT(*) FROM `logs_money` WHERE `id_user` = '$user->id' AND `type` = 'plus'")->fetchColumn();
$log_monm = $connect->query("SELECT COUNT(*) FROM `logs_money` WHERE `id_user` = '$user->id' AND `type` = 'minus'")->fetchColumn();
$new_admt = $connect->query("SELECT COUNT(*) FROM `tickets` WHERE `read_adm` = '0'")->fetchColumn();
$admt1 = $connect->query("SELECT COUNT(*) FROM `tickets` ")->fetchColumn();
if ($new_admt >= 1) {$newta='[<font color="red">+'.$new_admt.'</font>]';}else{$newta='';}
echo '<div class="title">Кабинет</div>';
echo '<div class="menu">&bull; <a href="/user/listauth"> История авторизация [<font color="gren">'.$auth_succ.'</font>/<font color="red">'.$auth_fail.'</font>]</a></div>';
echo '<div class="menu">&bull; <a href="/user/moneyhistory"> Движения средств [<font color="gren">'.$log_monp.'</font>/<font color="red">'.$log_monm.'</font>]</a></div>';
//echo '<div class="menu">&bull; <a href="/user/pascan"> Пасспортный проверка ['.($user['pascan_act']==1 ? '<font color="red">не подтвержден</font>':'<font color="gren">подтвержден</font>').']</a></div>';
echo '<div class="menu">&bull; <a href="/user/tg"> Telegram аккаунт ['.(!empty($user['tg_id']) ? '<font color="gren">подключен</font>' : '<font color="red">не подключен</font>').']</a></div>';
echo '<div class="menu">&bull; <a href="/user/sett"> Изменить пароль</a></div>';
echo '<div class="menu">&bull; <a href="/user/email"> Изменить E-Mail</a></div>';
echo '<div class="menu">&bull; <a href="/pay/"> Пополнить баланс</a></div>';
echo '<div class="menu">&bull; <a href="/user/exit"> Выход</a></div>';

if ($adm_id == 5) {
echo '<div class="title">Для Админов</div>';
$allon=$count_online_user + $count_online_guest;
echo '<div class="menu">&bull; <a href="/adm/tickets"> Админ | Тикеты ['.$admt1.'] '.$newta.'</a></div>';
echo '<div class="menu">&bull; <a href="/adm"> Панель управления ['.$allon.'] ('.$count_online_user.'/'.$count_online_guest.')</a></div>';
}
break;
case 'settings':
echo '<div class="title">Изменить пароль</div>';

$error = '';
			
if (isset($_POST['pass']) && isset($_POST['new_pass']) && isset($_POST['last_pass'])) {
if (empty($_POST['pass'])) {
$error.= 'Введите действующий пароль!<br/>';
}
elseif (md5(md5($_POST['pass'])) != $user['pass']) {
$error.= 'Действующий пароль введен неверно!<br/>';
}
elseif (empty($_POST['new_pass'])) {
$error.= 'Введите новый пароль!<br/>';
}
elseif (mb_strlen($_POST['new_pass']) < 3 or mb_strlen($_POST['new_pass']) > 15) {
$error.= 'Новый пароль должен содержать от 3 до 15 символов!<br/>';
}
elseif (empty($_POST['last_pass'])) {
$error.= 'Введите проверочный пароль!<br/>';
}
elseif ($_POST['last_pass'] != $_POST['new_pass']) {
$error.= 'Проверочный пароль введен неверно!<br/>';
}
elseif (md5(md5($_POST['new_pass'])) == $user['pass']) {
$error.= 'У вас задействован этот пароль!<br/>';
}
if ($error) {
echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
} else {
$stmt = $connect->prepare("update `users` set `pass` = ? where `login` = ? limit 1");
if ($stmt->execute(array(md5(md5($_POST['new_pass'])), $user['login']))) {
setcookie('pass', md5(md5($_POST['new_pass'])), time() + 3600 * 24 * 30);
echo '<div class="menu"><center><font color="gren">Пароль успешно изменен!</font></center></div><meta http-equiv="Refresh" content="3; "/>';
} else {
echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
}
}
}
echo '<div class="menu"><form action="" method="post">Действующий пароль:<br /><input type="password" name="pass" maxlength="15"/><br/>Новый пароль:<br /><input type="password" name="new_pass" maxlength="15"/><br/>Повторите новый пароль:<br /><input type="password" name="last_pass" maxlength="15"/><br/><input class="btn btn-default" type="submit" value="Изменить"/></form></div>';
break; 
case 'enter':
if (isset($_POST['submit'])) {
header('location: /user/menu');
}
echo '<div class="title">Авторизация</div>';
echo '<div class="menu">IP: '.filter($_SERVER['REMOTE_ADDR']).'<br/>
UA: '.filter($user['ua']).'<br/>
Время: '.date('d.m.Y H:i', $user['lasttime']).'</div>
<div class="menu"><form action="" method="post"><input class="btn btn-default" type="submit" name="submit" value="Войти в кабинет"></form>
Автологин:<br/><input type="text" value="'.ROOT.'/auth?login='.filter($user['login']).'&pass=ВАШ_ПАРОЛЬ"/></div>';
break;
case 'exit':
if ($set['close'] == 1) {

        if (isset($_POST['exit'])) {

            $reset_auth = $connect->prepare("update `authlog` set `status` = ? where `uid` = ? and `key` = ?");

            $reset_auth->execute(array(0, $user['id'], $authash));

            setcookie('user_id', null, time() - 3600, '/');
            setcookie('pass', null, time() - 3600, '/');
            setcookie('auth', null, time() - 3600, '/');

            header('Location: /');

        }
        echo '<div class="title">Выход с аккаунт</div>';
        echo '<div class="menu"><form action="" method="POST">
        Вы действительно хотите выйти с аккаунта?<br/>
        <input type="submit" class="btn btn-default" name="exit" value="Да, выйти">
        </form></div>';

    } else{
        echo '<div class="err">Вы не можете выйти с аккаунта пока сайт закрыт!</div>';

}
break;

}
} else {
header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
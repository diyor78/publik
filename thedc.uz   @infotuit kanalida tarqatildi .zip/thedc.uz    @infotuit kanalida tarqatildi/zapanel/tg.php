<?php
$title = 'Telegram аккаунт ';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
////////
if (isset($_GET['rand']) && empty($user['tg_sess'])) {
$ses=md5($time);
$connect->query("UPDATE `users` SET `tg_sess` = '$ses' WHERE `id` = '".$user->id."'");
header('Location: /user/tg');
}
////////////

echo '<div class="title">Telegram аккаунт</div>';
if (empty($user['tg_id'])) {
    echo '<div class="menu"><center><font color="red">Ваш телеграм аккаунт не подключен!</font></center></div>';
    echo '<div class="menu">Для подключение телеграм аккаунт отправите код активация на наш бот!<br/>
    <b>Наш бот</b>: @TheDCuz_Bot<br/>
    <b>Код активация</b>: '.(!empty($user['tg_sess']) ? filter($user['tg_sess']) : '<font color="red">нет код активация</font> <a href="/user/tg?rand">[Создать код активация] </a>').'</div>';
}else{
    echo '<div class="menu"><center><font color="gren">Ваш телеграм аккаунт подключен!</font></center></div>';
    echo '<div class="menu"><b>Ваш телеграм аккаунт ID</b>: '.filter($user['tg_id']).' ';
    echo '<div class="menu"><b>Команды для бот (@TheDCuz_Bot)</b>: <br/>
    "Баланс"  - Для проверка баланс!<br/>
    "Логин"  - Для узнать ваш логин!';
    echo '</div>';
}







} else {
header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 ?>
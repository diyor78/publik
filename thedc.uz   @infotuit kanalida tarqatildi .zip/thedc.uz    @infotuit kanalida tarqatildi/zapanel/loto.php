<?php
$title = 'Лотерея';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Лотерея</div>';
if (isset($_POST['submit'])) {
$err = '';
$stmt = $connect->prepare("select count(`id`) from `loto` where `idu` = ?");
$stmt->execute(array($user['id']));
$num = $stmt->fetchColumn();
if ($num > 0) {
$err.= 'Вы уже купили билет!<br/>';
}
if ($user['money'] < 1) {
$err.= 'Недостаточно средств!<br/>';
}
if ($err) {
echo '<div class="menu"><center><font color="red">'.$err.'</font></center></div>'; 
} else {
$stmt1 = $connect->prepare("update `users` set `money` = `money` - '1' where `id` = ?");
$stmt2 = $connect->prepare("insert into `loto` set `idu` = ?");
$cena='1';
$zaz='Заказ на билет лото';
$time=time();
$stmte = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'minus', `count` = ?, `action` = ?, `time` = ?");
if ($stmt1->execute(array($user['id'])) && $stmt2->execute(array($user['id'])) && $stmte->execute(array($user['id'],$cena,$zaz,$time))) {
echo '<div class="menu">Билет успешно куплен!</div>';
header('Refresh: 1');
} else {
echo '<div class="menu"><center><font color="red">Произошла ошибка!</font></center></div>';
}
}
}
echo '<div class="menu">Джек-под: '.$loto_count.' руб.<br/>Участвует пользователей: '.$loto_count.'<br/>Макс. число участников: '.val($set['loto']).'</div>';
$stmt = $connect->prepare("select count(`id`) from `loto` where `idu` = ?");
$stmt->execute(array($user['id']));
$num = $stmt->fetchColumn();

if ($num == 0) {
echo '<div class="menu"><form action="" method="post"><input class="btn btn-default" type="submit" name="submit" value="Купить билет (1 руб.)" /></form></div>';
} else {
$stmt = $connect->prepare("select * from `loto` where `idu` = '".$user['id']."'");
$stmt->execute(array($user['id']));
$loto = $stmt->fetch(PDO::FETCH_LAZY);
echo '<div class="menu">Ждите окончания лотереи! Ваш билет — '.val($loto['id']).'.</div>'; 
}
} else {
header('Location: /auth');} 
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 ?>
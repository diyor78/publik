<?php
$title = 'Раздачи Доступ';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Раздачи доступ</div>';
if ($_GET['daccess'] && $user['access_cp']) {
    $dacc = $connect->prepare("update `users` set `access_cp` = ? where `id` = ? limit 1");
if ($dacc->execute(array(0, $user['id']))) {
    header('Location: ?');
}
}
if (isset($_POST['ok']) && empty($user['access_cp'])) {
$stnum = $connect->prepare("select count(`id`) from `users` where `login` = ?");
$stnum->execute(array($_POST['login']));
$num = $stnum->fetchColumn();
$idd = uid($_POST['login']);
if (empty($_POST['login'])) {
$error.= 'Введите логин получателя!';
}
elseif ($num == 0) {
$error.= 'Пользователь с таким логином не найден в системе!';
}elseif($idd == $user['id']){
    $error.= 'Сам себе нельзя!<br/>';
}
if ($error) {
    echo '<div class="err">'.$error.'</div>';
}else{
    
    $dacc = $connect->prepare("update `users` set `access_cp` = ? where `id` = ? limit 1");
if ($dacc->execute(array($idd, $user['id']))) {
    header('Location: ?');
}
}

}
if ($user['access_cp']){
    echo '<div class="menu">вы дали доступ на '.ulogin($user['access_cp']).' [<a href="?daccess=deny">Удалить</a>]</div>';
}else{
    echo '<div class="menu">';
    echo '<form method="post" action="">
Логин:<br /><input type="text" name="login" maxlength="25"> <br />
<input class="btn btn-default" type="submit" name="ok" value="Активировать" />
</form>';
    echo '</div>';
}
} else {header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
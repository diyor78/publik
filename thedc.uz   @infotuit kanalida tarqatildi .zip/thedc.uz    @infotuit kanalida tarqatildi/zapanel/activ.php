<?php
$title = 'Восстановление пароля';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == false) {
echo '<div class="title">Восстановление пароля</div>';
$_SESSION['rand_pass'] = gen_pass();
if (isset($_GET['sess'])){
$stmtab = $connect->prepare("select count(*) from `forgot` where `sess` = ?");
$stmtab->execute(array($_GET['sess']));
$num = $stmtab->fetchColumn();
$error='';
if ($num == 0) {
$error= 'Ваш сессия устарела или нет такой сессия!';
header( "refresh:3;url=/" );
}
if ($error) {
echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
} else {
$forgota = $connect->prepare("SELECT * FROM `forgot` WHERE `sess` = ?");
$forgota->execute(array($_GET['sess']));
$forgot = $forgota->fetch(PDO::FETCH_LAZY);
$stmt = $connect->prepare("update `users` set `pass` = ? where `login` = ? limit 1");
if ($stmt->execute(array(md5(md5($_SESSION['rand_pass'])), $forgot['login']))) {
mailto($forgot['email'], 'Восстановление пароля TheDC.uz',
'Вы запросили восстановления пароля!<br/>
Ваш новый пароль: '.$_SESSION['rand_pass'].'<br/> Ссылка для автологина: '.ROOT.'/auth?login='.$forgot['login'].'&pass='.$_SESSION['rand_pass'].'<br/><br/>С Уважением, Администратор TheDC.uz',
$set['mail']);
$delsess = $connect->prepare("delete from `forgot` where `id` = ? limit 1");
$delsess->execute(array($forgot['id']));
echo '<div class="menu"><center><font color="gren">Ваш пароль выслан на указанный вами E-mail.</font></center></div>';
header( "refresh:3;url=/" );
} else {
echo '<div class="menu"><center><font color="red">Ошибка при восстановлении пароля!</font></center></div>';
}
}
}
if (empty($_GET['sess'])){
echo '<div class="menu"><center><font color="red">Нет сессия</font></center></div>';
    header( "refresh:3;url=/" );
}
} else {
header('Location: /user/menu');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
<?php
$title = 'Передать деньги';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
$ack = '1';
if (isset($active) && $ack) {
    echo '<div class="title">Передать деньги</div>';
    if ($user['accesstosm'] == 2){

    if (isset($_SESSION['send_summ']) && isset($_SESSION['send_login']) && isset($_SESSION['send_key'])) {

        if ($_SESSION['send_login'] == $user['login']) {

            unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);

            header('Location: /service/sendmoney');

        } else {

            if (isset($_POST['cancel'])) {

                unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);

                header('Location: /service/sendmoney');

            }
            elseif (isset($_POST['send_verify'])) {

                $error = '';

                if (empty($_POST['send_key'])) {
                    $error.= 'Введите код подтверждения!<br/>';
                }
                elseif ($_POST['send_key'] != $_SESSION['send_key']) {
                    $error.= 'Код подтверждения неверный!<br/>';
                }elseif (!preg_match("#^[0-9]{1,15}$#i", $_SESSION['send_summ'])){
                    $error.= 'OOPS! Только Integer!<br/>';
                }
                if ($error) {
                    echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
                } else {
                    if ($user['money'] > $_SESSION['send_summ']){
                    $summ = p($_SESSION['send_summ'], $amx['amx']['procent']);
                    $smm = $connect->prepare("update `users` set `money` = `money` - ? where `login` = ?");
                    $smmh = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'minus', `count` = ?, `action` = ?, `time` = ?");
                    $zaz='Вы передали деньги под логином <b>'.filter2($_SESSION['send_login']).'</b>';
                    if ($smm->execute(array($_SESSION['send_summ'], $user['login'])) && $smmh->execute(array($user['id'], $_SESSION['send_summ'], $zaz, $time))){
                       $smp = $connect->prepare("update `users` set `money` = `money` + ? where `login` = ?");
                       $smph = $connect->prepare("INSERT INTO `logs_money` SET `id_user` = ?, `type` = 'plus', `count` = ?, `action` = ?, `time` = ?");
                       $zazp='Вам перевел деньги <b>'.filter2($user['login']).'</b>';
                       if ($smp->execute(array($summ, $_SESSION['send_login'])) && $smph->execute(array(uid($_SESSION['send_login']), $summ, $zazp, $time))){
                           echo '<div class="menu"><center><font color="gren"><b>Вы успешно передали '.filter2($_SESSION['send_summ']).' рубль под логином '.filter2($_SESSION['send_login']).'!</b></font></center></div>';
                           unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);
                           header('Refresh: 2; url=/service/sendmoney');
                       }else {
                        echo '<div class="menu"><center><font color="red">Произошла ошибка! [1]</font></center></div>';
                    }
                    }else {
                        echo '<div class="menu"><center><font color="red">Произошла ошибка! [2]</font></center></div>';
                    }
                    
                }else {
                    echo '<div class="menu"><center><font color="red"><h1>ошибка передание деньги!</h1></font></center></div>';
                           unset($_SESSION['send_summ'], $_SESSION['send_login'], $_SESSION['send_key']);
                           header('Refresh: 2; url=/service/sendmoney');
                }
                }

            }
            echo '<div class="menu">Вы передаеты <b>'.filter2($_SESSION['send_summ']).'</b> рубль, под логином <b>'.filter2($_SESSION['send_login']).'</b></div>';
            echo '<div class="menu"><center><font color="gren">На <font color="red">'.filter2($user['email']).'</font> было отправлено письмо с кодом подтверждения.</font></center></div>';
            echo '<div class="menu">
            <form action="" method="POST">
            Код подтверждения:<br/><input type="text" name="send_key"><br/>
            <input class="btn btn-default" type="submit" name="send_verify" value="Подтвердить"><input class="btn btn-default" type="submit" name="cancel" value="Отмена">
            </form></div>';

        }

    } else {

        if (isset($_POST['submit'])) {

            $error = '';

            if (empty($_POST['col'])) {
            $error.= 'Введите сумму!<br/>';
            }
            elseif (!is_numeric($_POST['col'])) {
            $error.= 'Неверно введено количество!<br/>';
            }
            $stnum = $connect->prepare("select count(`id`) from `users` where `login` = ?");
            $stnum->execute(array($_POST['login']));
            $num = $stnum->fetchColumn();
            if (empty($_POST['login'])) {
            $error.= 'Введите логин получателя!<br/>';
            }
            elseif ($num == 0) {
            $error.= 'Пользователь с таким логином не найден в системе!<br/>';
            }
            elseif ($user['activ'] == 4) {
            $error.= 'Ваш аккаунт блокирован! вам нельзя!<br/>';
            }
            elseif (mb_strtolower($_POST['login']) == mb_strtolower($user['login'])) {
            $error.= 'Переводить на свой счет невозможно!<br/>';
            }
            elseif ($user['money'] < $_POST['col']) {
            $error.= 'Не достаточный денег со счета!<br/>';
            }
            elseif (!preg_match("#^[0-9]{1,15}$#i", $_POST['col'])){
                    $error.= 'OOPS! Только Integer!<br/>';
            }
            if ($error) {
                echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
            } else {

                $_SESSION['send_summ'] = $_POST['col'];
                $_SESSION['send_login'] = $_POST['login'];

                $_SESSION['send_key'] = random_int(11111, 99999);

                mailto(
                    $user['email'],
                    'Код для потверждения перевода UzXost',
                    'Код подтверждения: '.$_SESSION['send_key'],
                    $set['mail']
                );

                header('Location: /service/sendmoney');

            }

        }
        echo '<div class="menu">Дорогие друзья с этом сервисом вы можете передать или продавать денги со своего внутренного счета.<br/>
        Коммисия за сервиса <b>'.$amx['amx']['procent'].'%</b> от суммы.</div>';
        echo '<div class="menu"><form action="?" method="post">
        Сумма:<br/><input type="text" name="col" maxlength="10"/><br/>
        Пользователь:<br/><input type="text" name="login" maxlength="15"/><br/>
        <input class="btn btn-default" type="submit" name="submit" value="Передать"/></form></div>';

    }

}else{
    echo '<div class="menu"><center><font color="red">У вас нет доступ к Передать деньги!</font></center></div>';
    echo '<div class="menu"><a href="/"> Дальше</a></div> ';
}
} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
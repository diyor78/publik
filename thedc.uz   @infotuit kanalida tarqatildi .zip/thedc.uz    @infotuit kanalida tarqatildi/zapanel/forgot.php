<?php
$title = 'Восстановление пароля';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == false) {
echo '<div class="title">Восстановление пароля</div>';
$_SESSION['rand_pass'] = gen_pass();
if (isset($_POST['login']) && isset($_POST['email']) && isset($_POST['code'])) {
$error = '';
$stmt = $connect->prepare("select count(`id`) from `users` where `login` = ?");
$stmt->execute(array($_POST['login']));
$num = $stmt->fetchColumn();
if (empty($_POST['login'])) {
$error.= 'Введите логин в системе!<br/>';
}
elseif (mb_strlen($_POST['login']) < 3 or mb_strlen($_POST['login']) > 15) {
$error.= 'Логин должен содержать от 3 до 15 символов!<br/>';
}
elseif ($num == 0) {
$error.= 'Пользователя с таким логином не существует!<br/>';
}
$stmt = $connect->prepare("select count(`id`) from `users` where `login` = ? and `email` = ?");
$stmt->execute(array($_POST['login'], $_POST['email']));
$num = $stmt->fetchColumn();
if (empty($_POST['email'])) {
$error.= 'Введите ваш почтовый ящик!<br/>';
}
elseif (!preg_match('|^([a-z0-9_\.\-]{1,20})@([a-z0-9\.\-]{1,20})\.([a-z]{2,4})$|ius', $_POST['email'])) {
$error.= 'Поле e-mail заполнено неверно!<br/>';
}
elseif ($num == 0) {
$error.= 'Неверно введен почтовый ящик!<br/>';
}
if (empty($_POST['code'])) {
$error.= 'Введите код с картинки!<br/>';
}
elseif ($_SESSION['code'] != $_POST['code']) {
$error.= 'Код с картинки введен неверно!<br/>';
}
if ($error) {
echo '<div class="menu"><center><font color="red">'.$error.'</font></center></div>';
} else {
$stmt = $connect->prepare("insert into `forgot` set `sess` = ?,`login` = ?,`email` = ?, `time` = ?");
if ($stmt->execute(array(md5(md5($_SESSION['rand_pass'])), $_POST['login'], $_POST['email'], $time))) {
mailto($_POST['email'], 'Восстановление пароля',
'Вы запросили восстановления пароля!  (<font color=red>Сессия действует точно 20 минут!</font>)<br/>
Для восстановление пароль! кликнуйте на этом ссылка! <a href="https://uzxost.ru/activ/sess/'.md5(md5($_SESSION['rand_pass'])).'">Ссылка</a> <br/><br/>С Уважением, Администратор UzXost.Ru',
$set['mail']);
echo '<div class="menu"><center><font color="gren">Данные высланы на указанный вами E-mail.</font></center></div>';
} else {
echo '<div class="menu"><center><font color="red">Ошибка при восстановлении пароля!</font></center></div>';
}
}
}
echo '<div class="menu"><form action="" method="post">Логин:<br/><input type="text" name="login" maxlength="15"/><br/>E-mail:<br /><input type="text" name="email" maxlength="35"/><br/>Код с картинки:<img src="/inc/code.php" alt="check"><br /><input type="text" name="code" /><br/><input class="btn btn-default" type="submit" value="Восстановить"/></form></div>';
} else {
header('Location: /user/menu');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
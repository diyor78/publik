<?php
list($msec,$sec)=explode(chr(32),microtime());

if ($_SERVER['PHP_SELF'] != '/index.php') {
echo '</div>';
echo '<div class="menu"><a href="/"><img src="/inc/style/img/up.png"> На главную</a></div> '; 
}

echo '</div><footer>';

?>

<span>&copy; <b>TheDC.uz</b> - <?=date('Y');?></span>

<script>
window.replainSettings = { id: '001fc292-aa2f-4374-a2e1-88f0315bb4a4' };
(function(u){var s=document.createElement('script');s.type='text/javascript';s.async=true;s.src=u;
var x=document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);
})('https://widget.replain.cc/dist/client.js');
</script>


      </footer>
    </div>
<center>
<a class="replain-link" href="#replain" data-title="Support" data-border="#FGFGFG" data-background="#06DF77" data-color="#FFFFFF">Support</a>
<?
/*
<div class="center">Ген. <?=round(($sec+$msec)-$headtime,3)?> сек.</div>
*/
?>
   </body>
</html>
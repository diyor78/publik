include_once '../sys/inc/start.php';
$doc = new document();
$doc->theme = __('Уведомление');
$doc->msg(__msg('Баланс успешно пополнен'));
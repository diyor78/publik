<?
include_once '../sys/inc/start.php';
$doc = new document();
$doc->theme = __('Уведомление');
$doc->err(__('Произошла ошибка при пополнении'));
?>
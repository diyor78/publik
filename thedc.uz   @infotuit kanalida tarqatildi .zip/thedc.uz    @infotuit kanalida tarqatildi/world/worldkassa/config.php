<?
$id_shop='';//ID площадки на WorldKassa
$hash='';//Секретный ключ (HASH)
?>
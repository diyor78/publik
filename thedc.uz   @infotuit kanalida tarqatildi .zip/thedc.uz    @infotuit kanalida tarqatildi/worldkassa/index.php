<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
include_once($_SERVER["DOCUMENT_ROOT"]."/config.php");
$doc = new document();
$doc->title = __('Пополнить баланс');
if (isset($_POST['summa']))
	{
	if (preg_match('#^([0-9]+)$|^([0-9]+\.)+([0-9]{1,2})$#', $_POST['summa']))
		{
		$data=file_get_contents('http://worldkassa.ru/user/oplata.php?id_shop='.$id_shop.'&summa='.$_POST['summa'].'&hash='.$hash);
		if (is_numeric($data))
			{
			mysql_query("INSERT INTO `worldkassa` (`id_user`, `id_bill`, `time`, `summa`) values('".$user->id."', '".$data."', '".TIME."', '".$_POST['summa']."')");
			header("Location: http://worldkassa.ru/user/oplata.php?uniq=".$data);
			exit();
			}
			else
			{
			$err[]=$data;
			}
		}
		else
		{
		$err[]='Введите корректно сумму';
		}
	}
echo 'Ваш баланс '.$user->balans.' Rub<br/>
Пополнить на:<br/>
<form action="?" method="post">
<input name="summa" type="text" value="1.00"/> RUB<br/>
<input type="submit" value="Пополнить"/>
</form>';
?>
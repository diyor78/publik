include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
$doc = new document();
$doc->theme = __('Уведомление');
$doc->msg(__msg('Баланс успешно пополнен'));
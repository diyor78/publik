<?php
$id_shop='6738';//ID площадки на WorldKassa
$hash='AbfnAJk';//Секретный ключ (HASH)
?>
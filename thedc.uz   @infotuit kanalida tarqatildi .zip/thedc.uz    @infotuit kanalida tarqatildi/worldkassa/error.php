<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
$doc = new document();
$doc->theme = __('Уведомление');
$doc->err(__('Произошла ошибка при пополнении'));
?>
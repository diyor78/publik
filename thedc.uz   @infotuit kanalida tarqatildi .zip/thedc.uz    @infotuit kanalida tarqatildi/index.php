<?php
$title = 'Mobil veb-sayt xosting!';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
$ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
$ontarif->execute(array($user['id_tarif']));
$ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
// Akkauntni aktivlash
/*if ($user[test]==1){
    if (isset($_POST['ok']))
{
    $code=val($_POST['code']);
    if ($user[wmr]==$code) {
        $connect->query("update `users` set `test` = '2' where `id` = ".$user['id']."");
        $redsa='';
        header('Location: /');
    }else{
        $redsa='<div class="menu"><center><font color="red">Неверно! Код активация!</font></center></div>';
    }
    
    
}
*/
$oks=$_SESSION['ok'];
/*
if (isset($_POST['else'])) {
$qa1='1';
$qasss=$_SESSION['ok']+$qa1;
$_SESSION['ok'] = $qasss;
*/
if ($oks<=2){
mailto(
$user['email'],
'TheDC.uz | Mobil veb-sayt xosting! ',
'TheDC.Uz | Tezkor hosting xizmati!<br/>
=========================<br/>
Bizni tanlaganingiz uchun tashakkur!<br/>

login:'.$user['login'].'<br/>
=========================<br/>
Eslatib o`tamiz!<br/>
=========================<br/>
Bizning NS serberlar nomi:<br/>
ns1.thedc.uz<br/>
ns2.thedc.uz<br/>
',
$set['mail']
);
}

/*
mailto($user->email, 'TheDC.uz | Активация аккаунт! ','TheDC.uz | Мобильный хостинг!<br/>Ваш логин: '.$user->login.'<br/>Код активация: '.$user->wmr.'<br/><br/>С Уважением Администратор TheDC.uz! ', $set['mail']);
$redsa='<div class="menu"><center><font color="gren">На Ваш почта отправлен код активация!</font></center></div>';
}else{$redsa='<div class="menu"><center><font color="red">Вы много отправиль код активатция на ваш E-Mail!!!</font></center></div>';}}
if ($redsa) echo $redsa;
    echo '<div class="title">Подтверждение почта!</div>';
    echo '<div class="menu"><font color=red>Ваш Почта</font>: <b>'.$user->email.'</b><br/>
    <font color="red">Раздел Восстановление пароля не доступен, пока не будет подтвержден MAIL адрес!</font>
<form method="post">
Код активация [0-9]:<br /><input type="text"  name="code" pattern="^[0-9]{3,7}$"/> <br />
<input class="btn btn-default" type="submit" name="ok" value="Активировать" /><input class="btn btn-default" type="submit" name="else" value="Отправить код активация ещё" />
</form></div>';}*/
echo '<div class="title">Mening Hisobim</div>';
if ($user[activ]==0) {$c1='<font color="red">faollashtirilmagan!</font> ()';}
if ($user[activ]==1) {$c1='<font color="red">faollashtirilmagan!</font>'; $c2='Faollashtirish uchun Hisobingizni '.$ustarif['price_day'].' rubl ga <a href="/pay">to`ldiring</a>';}
if ($user[activ]==2) {$c1='<font color="gren">Faol!</font>';}
if ($user[activ]==3) {$c1='<font color="red">uzilgan!</font>'; $c2='Shaxsiy hisobingizda mablag` yo`qligi sababli hisobingiz to`xtatildi. Shaxsiy hisobingiz haqida batafsil ma`lumotni mening hisobim panelida topishingiz mumkin.. Diqqat! 7 kundan ortiq vaqt davomida tarif to`lanmasa, <a href="http://uzxost.ml/info/rules/">Hosting qoidalari</a>ga ko`ra - sizning ma`lumotingiz qayta tiklanmasdan avtomatik ravishda yo`q qilinadi.</span><br/>Faollashtirish uchun Hisobingizni '.$ustarif['price_day'].' rubl ga <a href="/pay">to`ldiring</a>';}
if ($user[activ]==4) {$c1='<font color="red">bloklangan!</font>';}
if (empty($c1)) {$c1='<font color="red">Xato :)</font>';}
if($user['money']>=$ustarif['price_day'] && $user[activ] <> 2){
    $ts='0';
echo '<div class="ok">Hisobga ishlov berilmoqda! Iltimos, faollashtirishni kuting!</div>';}else{$ts='1';}
echo'<div class="menu">
<b>Assalomu Alaykum</b>, <b>'.filter($user['login']).'</b>!<br/>
<b>Soat</b>: <span id="time">'.date('H:i:s',time()).' </span>UZB<br/>
<b>Server</b>: <b>№1 [MCK]</b> <br/>
<b>Sizning balansingiz</b>: <b>'.filter($user['money']).' Rub</b> <a href="/pay"><b>+To`ldirish</b></a><br/>';
$usm=$user[money];
$tcm=$ustarif['price_day'];
if ($tcm == 0) {$k='9999';}else{
for ($k=0;$tcm <=$usm;$k++){
    $usm=$usm-$tcm;
}
}
if ($k >= 1) {
    $allc = 86400 * $k;
}else{$allc='0';}
if ($user['activ'] >= 2) {
echo ''.order_day(($user['time_work'] + $allc)).' <b>kun qoldi</b> (<b>hisob</b>: '.vremja(($user['time_work'] + $allc)).' <b>gacha faol</b>)<br/>
'.(order_day($user['time_work'],true) < 0.01 ? '<font color="red"><b>До сброс аккаунт осталось</b>: '.order_day(($user['time_work'] + (84600 * 7))).' дней. </font><br/>' : '').' ';}
echo '<b>Tarif</b>: <b>'.$ustarif['name'].' ('.$ustarif['price_day'].' руб/день)</b><br/>
'.($user['activ']==2 ? '<b>Sizning domeningiz: <a href="http://'.filter($user['login']).'.TheDC.uz" target="_blank">'.filter($user['login']).'.TheDC.uz</a></b><br/>' : '').'
<b>Hisobingizni hozirgi holati:  '.$c1.'</b>
</div>';
if ($c2 && $ts && empty($user['money']>=$ustarif['price_day'])) {
echo'<div class="menu"><h1 style="color: red;"><b>Diqqat!</b></h1>';
echo '<font color="red">'.$c2.'</font>';
echo '</div>';
}
echo '<div class="title">Xizmatlar</div>';
echo '<div class="menu"><img src="../icon/host.png" alt="*" width="16px" height="16px"/><a href="/tarifs/hosting"> Virtual hosting [Tariflar] [Tarifni o`zgartirish]</a></div>';
echo '<div class="title">Sayt menyusi </div>';
if (isset($user) && $user['activ'] == 2){
echo '<div class="menu"><img src="https://mgr.uzxost.ru/icon/file.png" alt="*" width="16px" height="16px"/> <a href="/authcp"> Sayt boshqaruvi [CP | ISP]</a></div>';
}
echo '<div class="menu"><img src="https://mgr.uzxost.ru/icon/global.png" alt="*" width="16px" height="16px"/> <a href="/service"> Xizmatlar [2]</div>';
echo '<div class="menu"><img src="../icon/chat.png" alt="*" width="16px" height="16px"/> <a href="/user/chat"> Suhbatlashuv </a>['.$ch.'<font color=red>'.$new_chat.'</font>]</div>';
echo '<div class="menu"><img src="../icon/new.png" alt="*" width="16px" height="16px"/> <a href="/news"> Yangiliklar </a>['.$count_news.''.$new_news.']</div>';
echo '<div class="menu"><img src="../icon/adm.png" alt="*" width="16px" height="16px"/> <a href="/info/support"> Qo`llab-quvatlash markazi</a></div>';
echo '<div class="menu"><img src="../icon/pc.png" alt="*" width="16px" height="16px"/> <a href="/info/server"> Server sozlamalari</a></div>';
echo '<div class="menu"><img src="../icon/rule.png" alt="*" width="16px" height="16px"/> <a href="/info/rules"> Hosting qoidalari</a></div>';
echo '<div class="menu"><img src="../icon/ipay.png" alt="*" width="16px" height="16px"/> <a href="/info/pay"> To`lov usullari</a></div>';

echo '<div class="title">Ijtimoiy tarmoqlar</div>';
echo '<div class="menu"><img src="../icon/tg.png" alt="*" width="16px" height="16px"/> <a href="https://t.me/thedcuz"> Telegram</a></div>';
}else{

echo '<div class="title">Bizning afzalliklarimiz</div><div class="menu">
✓ Telefoningizdan saytni to`liq boshqarish!<br/>
✓ PHP 5.4 / 5.6 / 7.2 va MySQL, DNS <-ni qo`llab-quvvatlash<br/>
✓ Har bir domen uchun PHP versiyasini tanlash<br/>
✓ FTP-saytlaringizga kirish<br/>
✓ Bepul SSL sertifikati(Let’s Encrypt)<br/>
✓ Sub-domenlar yaratish va domenlar boshqaruvi!</div>';


echo '<div class="title">Xizmatlar</div>';
echo '<div class="menu"><img src="../icon/host.png" alt="*" width="16px" height="16px"/> <a href="/tarifs/hosting"> Virtual hosting [Tariflar]</a></div>';
echo '<div class="title">Sayt menyusi </div>';
echo '<div class="menu"><img src="../icon/new.png" alt="*" width="16px" height="16px"/> <a href="/news"> Yangiliklar </a>['.$count_news.''.$new_news.']</div>';
echo '<div class="menu"><img src="../icon/adm.png" alt="*" width="16px" height="16px"/> <a href="/info/support"> Qo`llab-quvatlash markazi</a></div>';
echo '<div class="menu"><img src="../icon/pc.png" alt="*" width="16px" height="16px"/> <a href="/info/server"> Server sozlamalari</a></div>';
echo '<div class="menu"><img src="../icon/rule.png" alt="*" width="16px" height="16px"/> <a href="/info/rules"> Hosting qoidalari</a></div>';
echo '<div class="menu"><img src="../icon/ipay.png" alt="*" width="16px" height="16px"/> <a href="/info/pay"> To`lov usullari</a></div>';

echo '<div class="title">Ijtimoiy tarmoqlar</div>';
echo '<div class="menu"><img src="../icon/tg.png" alt="*" width="16px" height="16px"/> <a href="https://t.me/thedcuz"> Telegram</a></div>';
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
<?php 
$k_post = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `activ`='1' AND `id_server` = '1'");
$k_post = $k_post->fetchColumn();
$k_page = k_page($k_post, 10);
$page = page($k_page);
$start = 10*$page-10;

if ($k_post==0) {
    echo '<div class="menu"><center><font color="red">Тарифы нету</font></center></div>';
}

$q = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `activ`='1' AND `id_server` = '1' ORDER BY `sort` ASC LIMIT $start, 10")->fetchAll();

foreach ($q as $hosting){ 

echo '<div class="title">  <b>'.filter($hosting[name]).'</b></div><div class="menu">'; 


echo '<b>Место на диске:</b> '.filter($hosting[hdd]).' MB<br/> 
<b>Трафик:</b> '.filter($hosting[trafic]).' Gb<br/> 
<b>Доменов/поддоменов:</b> '.filter($hosting[domain]).' шт.<br/> 
<b>FTP-доступ:</b> '.filter($hosting[ftp]).' шт.<br/> 
<b>POP3-ящики:</b> '.filter($hosting[mail]).' шт.<br/> 
<b>Базы данных:</b> '.filter($hosting[mysql]).' шт.<br/>
__________________<br/>
<b>Цена в день:</b> '.filter($hosting[price_day]).' руб.<br/> 
<b>Цена в месяц:</b> '.filter($hosting[price_month]).' руб.<br/> 
<b>Цена в год:</b> '.filter($hosting[price_year]).' руб.<br/>';
if ($user) {   
    if ($user[id_tarif] == $hosting[id]){
        $url = '<div class="okt">Вы используете данный тариф!</div></div>';
    }else {
       $url = '<a href="/user/smenat/'.$hosting[id].'"><center> <input class="btn btn-default" type="submit" value="Перейти на '.filter($hosting[name]).'"></center></a></div>';
    }
}else{
    $url = '<a href="/reg"><center> <input class="btn btn-default" type="submit" value="Заказать"></center></a></div>';
}
echo ' '.$url.'';
} 
if ($k_page > 1) navigation($k_page, $page); 
?>
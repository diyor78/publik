<?php
$title = 'Пользователи';
require_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if ($adm_id == 5) {

    echo '<div class="title">Пользователи</div>
    <div class="menu">
    <form action="" method="GET">
    <input type="text" name="search" value="'.$search.'">
    <input class="btn btn-default" type="submit" value="Поиск">
    </form></div>';

    $keywords = preg_replace("/[\s,]+/", "|", $search);

    $stmt_num = $connect->prepare("select count(*) from `users` where `login` rlike :keywords");
    $stmt_num->bindValue(':keywords', $keywords);
    $stmt_num->execute();
    $count_res = $stmt_num->fetchColumn();

    if ($count_res == 0) {
        echo '<div class="menu"><center><font color="red">Пусто</font></center></div>';
    } else {

         $k_post = $count_res;
$k_page = k_page($k_post, 10); 
$page = page($k_page);
$start = 10 * $page - 10;


        $data = $connect->prepare("select * from `users` where `login` rlike :keywords order by `id` desc limit :start, 10");
        $data->bindValue(':keywords', $keywords);
        $data->bindValue(':start', $start, PDO::PARAM_INT);
        $data->execute();
        $sql = $data->fetchAll();

        foreach ($sql as $row) {
            if ($row[activ]==0) {$c1='<font color="red">аккаунт не активирован!</font> (0)';}
if ($row[activ]==1) {$c1='<font color="red">аккаунт не активирован!</font>(1)';}
if ($row[activ]==2) {$c1='<font color="gren">аккаунт Активен!</font>(2)';}
if ($row[activ]==3) {$c1='<font color="red">аккаунт отключен!</font>(3)';}
if ($row[activ]==4) {$c1='<font color="red">аккаунт блокирован!</font>(4)';}
if (empty($c1)) {$c1='Error';}
            echo '<div class="menu"><img src="/inc/style/img/user.png" alt="'.filter($row['login']).'"><a href="/adm/users/id/'.$row['id'].'"> '.filter($row['login']).'</a> '.online($row['id']).' ('.vremja($row['lasttime']).')';
            echo '<div class="st_1"></div><div class="st_2">
            <b>Баланс</b>: '.filter($row['money']).' Руб <br/>
            <b>Активность</b>: '.$c1.'<br/>
            <b>Дата регистрации</b>: '.vremja($row['datereg']).'</div></div>';
        }

        if ($k_page > 1) str('?search='.$search, $k_page, $page);

    }
    echo '<div class="menu">&bull;<a href="/adm/users/mail"> Поиск по почта</a></div>
    <div class="menu">&bull;<a href="/adm/users/ajaxs"> AJAX Поиск по Логин</a></div>
    <div class="menu">&bull;<a href="/adm/users/ip"> Поиск по IP</a></div>
    <div class="menu">&bull;<a href="/adm"> Панель управления</a></div>';
} else {
    header('Location: /');
}

require($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
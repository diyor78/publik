<?php
$title='Используемые ресурсы';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
    $ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
    $ontarif->execute(array($user['id_tarif']));
    $ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
    $server = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($ustarif[id_server]))."'");
    $server = $server->fetch(PDO::FETCH_LAZY);
$content = api_query('https://'.$server->ip.'/ispmgr?func=userstat&out=xml&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
$parse_xml = simplexml_load_string($content);

echo '<div class="title">Используемые ресурсы</div>';

echo '<div class="menu">';
echo '<b>Диск</b>: '.$parse_xml->elem[18]->usages_used.' Мб / '.$parse_xml->elem[18]->usages_total.' Мб <br/>';
echo '<b>Базы данных</b>: '.$parse_xml->elem[1]->usages_used.' шт / '.$parse_xml->elem[1]->usages_total.' шт <br/>';
echo '<b>Размер общий Базы данных</b>: '.$parse_xml->elem[3]->usages_used.' Мб / '.$parse_xml->elem[3]->usages_total.' Мб <br/>';
echo '<b>Почтовые ящики</b>: '.$parse_xml->elem[7]->usages_used.' шт / '.$parse_xml->elem[7]->usages_total.' шт <br/>';
echo '<b>FTP аккаунты</b>: '.$parse_xml->elem[8]->usages_used.' шт / '.$parse_xml->elem[8]->usages_total.' шт <br/>';
echo '<b>Сайтов (Домены/Поддомены)</b>: '.$parse_xml->elem[21]->usages_used.' шт / '.$parse_xml->elem[21]->usages_total.' шт <br/>';
echo '</div>';
} else {
header('Location: /');
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
<?php
$title = 'Вход на ISP Manager WAP';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");
if (isset($active) == true) {
echo '<div class="title">Вход на ISP Manager WAP</div>';
$id_tarifpa = $connect->query("SELECT * FROM `tarifs_hosting` WHERE `id` = '".$user[id_tarif]."'");
    $id_tarifpa = $id_tarifpa->fetch(PDO::FETCH_LAZY);
    $serverpa = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($id_tarifpa->id_server))."'");
    $serverpa = $serverpa->fetch(PDO::FETCH_LAZY);
    $kauth = md5(md5(time()));
    $qas=array("ssl"=>array("verify_peer"=>false,"verify_peer_name"=>false,),);
    $f = file_get_contents("https://".$serverpa->ip."/?authinfo=".urlencode($serverpa->login).":".urlencode($serverpa->pass)."&out=xml&func=session.newkey&username=".urlencode($user[isp_login])."&key=".$kauth."", false, stream_context_create($qas));
    if(preg_match('<ok/>',$f)){
    header('Location: https://isp.thedc.uz/ispmgr?func=auth&username='.$user[login].'&key='.$kauth.'&theme=z-mobile&checkcookie=no');
    }else{
        echo '<div class="err">OOPS</div>';
    }

} else {header('Location: /auth');}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
?>
<?php
$title = 'TheDC.uz | Sayt boshqaruvi!';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");

echo '<div class="title">WebHook sozlash hizmati!</div>';
?>
<html>


<body>
  <div class="menu">
    <div id="app" class="section">
      <form :action="set_webhook" method="post" enctype="multipart/form-data">
        <label class="label">Tokenni kiriting</label>
        <p class="control">
          <input class="input" type="text" v-model="token" />
        </p>
        <label class="label">Host URL ni kiriting ( "https://" kerak emas )</label>
        <p class="control">
          <input class="input" type="text" v-model="host" />
        </p>
       
        
        <div class="control is-grouped">
          <p class="control">
<center><button class="button" name="submit">Webhookni sozlash</button></center>
          </p>
          <br/>
          <p class="control">
          </p>
        </div>
    </div>
  </div>
  <script>
    new Vue({
      el: '#app',
      data: {
token: '',
host: '',
      },
      computed: {
        get_webhook_info: function () {
          return 'https://api.telegram.org/bot' + this.token + '/getwebhookinfo'
        },
        set_webhook: function () {
          return 'https://api.telegram.org/bot' + this.token + '/setwebhook?url=' + this.host
        },
      }
    }

    )
  </script>
</body>
</html>

<?

include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 ?>
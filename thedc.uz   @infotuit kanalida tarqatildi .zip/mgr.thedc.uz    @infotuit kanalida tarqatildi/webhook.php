
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#5d80a6">
<link rel="apple-touch-icon-precomposed" href="/inc/style/img/app-icon.png">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="/inc/style/style.css" rel="stylesheet">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Хостинг, Посуточный оплата, TheDC.uz Мобильный Хостинг,Мобильный Хостинг,TheDC.uz, php 7, ffmpeg, GD,(pdo) MySQL(i), sqlite, Curl,IonCube, выбор версии php"/>
<meta name="description" content="TheDC.uz-dan xosting - kechayu-kunduz qo`llab-quvvatlaydigan yuqori sifatli veb-xosting. Osiyoda ishonchli Linux hosting [#Bek]"/> 
<meta name="author" content="#Bek"/>
<meta name="copyright" content="#Bek!"/>
<meta http-equiv="content-language" content="ru"/>
<title>Менеджер Файлов</title></head><body><header>
         <table>
            <tr>
               <td class="l_bar">
<a href="/"><img src="/inc/style/img/home.png" width="23"  alt="home"></a>
               </td>
               <td class="c_bar">
                  <h1 id="logo"><b>TheDC.uz - Sayt boshqaruvchisi</b></h1>
               </td>
               <td class="r_bar">
<a href="/user/menu" title="Mening kabinetim"><img width="25" src="/img/us2.png" alt="Mening kabinetim"></a>
</td> </tr>
         </table>
      </header><style>
    .rek{
        float: right;
        color: red;
    }
</style>
<div class="mOm"><div class="block first"><html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#5d80a6">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="apple-touch-icon-precomposed" href="/inc/style/img/app-icon.png">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="/style.css" rel="stylesheet">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="/inc/style/style.css" rel="stylesheet">

  <link href="/inc/style/style.css?20190126144433" rel="stylesheet">
  <script src="https://unpkg.com/vue/dist/vue.js"></script>
  
<script type="text/javascript" src="/js/jquery.js"></script>
<script type="text/javascript" src="/js/function.js"></script>
<script src="/js/jquery.ajaxRequest.js"></script>
<script src="/js/qor.js"></script>
<script src="/js/jquery.timers.min.js"></script>
<script src="/js/jquery.plugins.js"></script>
<script src="/js/function.js"></script>
<script src="/js/time.js"></script>
<script src="/js/main.ajaxRequest.js"></script>

</head>
<body>
  <div class="container">
    <div id="app" class="section">
      <form :action="set_webhook" method="post" enctype="multipart/form-data">
        <label class="label">Tokenni kiriting</label>
        <p class="control">
          <input class="input" type="text" v-model="token" />
        </p>
        <label class="label">Host URL ni kiriting ( "https://" kerak emas )</label>
        <p class="control">
          <input class="input" type="text" v-model="host" />
        </p>
        <br/>
        <p style="color:blue">{{ sayt_ishlamayapti }}</p>
        <br/>
        
        <div class="control is-grouped">
          <p class="control">
<center><button class="button" name="submit">Webhookni sozlash</button></center>
          </p>
          <br/>
          <p class="control">
          </p>
        </div>
    </div>
  </div>
  <script>
    new Vue({
      el: '#app',
      data: {
token: '',
host: '',
      },
      computed: {
        get_webhook_info: function () {
          return 'https://api.telegram.org/bot' + this.token + '/getwebhookinfo'
        },
        set_webhook: function () {
          return 'https://api.telegram.org/bot' + this.token + '/setwebhook?url=' + this.host
        },
      }
    }

    )
  </script>
</body>
</html>
<div class="menu"><img src="/inc/style/img/up.png"><a href="https://mgr.thedc.uz">Bosh sahifa</a></div> <footer><span>&copy; <b><a href="https://thedc.uz">TheDC.uz</a></b> - 2020</span>
      </footer>

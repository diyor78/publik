<?php
$title = 'TheDC.uz | Sayt boshqaruvi!';
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/head.php");

if ($user){
$ontarif = $connect->prepare("select * from `tarifs_hosting` where `id` = ?");
$ontarif->execute(array($user['id_tarif']));
$ustarif = $ontarif->fetch(PDO::FETCH_LAZY);
// Akkauntni aktivlash
/*
if ($user[test]==1){
    if (isset($_POST['ok']))
{
    $code=val($_POST['code']);
    if ($user[wmr]==$code) {
        $connect->query("update `users` set `test` = '2' where `id` = ".$user['id']."");
        $redsa='';
        header('Location: /user/menu');
    }else{
        $redsa='<div class="menu"><center><font color="red">Неверно! Код активация!</font></center></div>';
    }
    
    
}
$oks=$_SESSION['ok'];
if (isset($_POST['else'])) {
$qa1='1';
$qasss=$_SESSION['ok']+$qa1;
$_SESSION['ok'] = $qasss;
if ($oks<=2){
mailto($user->email, 'TheDC.uz | Активация аккаунт! ','TheDC.uz | Мобильный хостинг!<br/>Ваш логин: '.$user->login.'<br/>Код активация: '.$user->wmr.'<br/><br/>С Уважением Администратор ZaDc.Ru! ', $set['mail']);
$redsa='<div class="menu"><center><font color="gren">На Ваш почта отправлен код активация!</font></center></div>';
}else{$redsa='<div class="menu"><center><font color="red">Вы много отправиль код активатция на ваш E-Mail!!!</font></center></div>';}}
if ($redsa) echo $redsa;
    echo '<div class="title">Подтверждение почта!</div>';
    echo '<div class="menu"><font color=red>Ваш Почта</font>: <b>'.$user->email.'</b><br/>
    <font color="red">Раздел Восстановление пароля не доступен, пока не будет подтвержден MAIL адрес!</font>
<form method="post">
Код активация [0-9]:<br /><input type="text"  name="code" pattern="^[0-9]{3,7}$"/> <br />
<input class="btn btn-default" type="submit" name="ok" value="Активировать" /><input class="btn btn-default" type="submit" name="else" value="Отправить код активация ещё" />
</form></div>';}
*/
 if ($user[activ] == 2) {
      $server = $connect->query("SELECT * FROM `servers` WHERE `id` = '".abs(intval($ustarif[id_server]))."'");
      $server = $server->fetch(PDO::FETCH_LAZY);
     $content = api_query('https://'.$server->ip.'/ispmgr?func=userstat&out=xml&authinfo=' . $user['isp_login'] . ':' . $user['isp_pass']);
     $parse_xml = simplexml_load_string($content);
     echo '<div class="title">Assalomu alaykum, '.filter($user['login']).'! </div>';
     echo '<div class="menu"><b><img src="../icon/disk.png" alt="*" width="16px" height="16px"/>  Xotira</b>: '.$parse_xml->elem[18]->usages_used.' / '.$parse_xml->elem[18]->usages_total.' MiB     </div>';
     echo '<div class="title">Mening menyuim!</div>';
echo '<div class="menu"><img src="../img/hook.png" alt="*" width="16px" height="16px"/> <a href="/webhook"> Webhook Hizmati </a><font color="red">[NEW]</font></a></div>'; 
     echo '<div class="menu"><img src="../icon/domen.png" alt="*" width="16px" height="16px"/> <a href="/domen"> WWW domenlar (sub-domenlar)</a></div>';
     echo '<div class="menu"><img src="../icon/ptichka.png" alt="*" width="16px" height="16px"/> <a href="/ssl"> SSL sertifikatlar</a></div>';
     echo '<div class="menu"><img src="../icon/ftp.png" alt="*" width="16px" height="16px"/> <a href="/ftp"> FTP hisoblar</a></div>';
 echo '<div class="menu"><img src="../icon/fileuz.png" alt="*" width="16px" height="16px"/> <a href="/mgr/explode.php?d=L3d3dy8="> Fayl menejeri</a></div>'; 
  echo '<div class="menu"><img src="../icon/men.png" alt="*" width="16px" height="16px"/> <a href="/webfmaa"> Fayl menejeri [WEB] </a><font color="red">[NEW]</font></a></div>'; 
     echo '<div class="menu"><img src="../icon/baza.png" alt="*" width="16px" height="16px"/> <a href="/db"> Ma`lumotlar bazasi (MySql)</a></div>';
 
 echo '<div class="menu"><img src="../icon/joy.png" alt="*" width="16px" height="16px"/> <a href="/infor"> Foydalanilgan manbalar</a></div>';
 echo '<div class="menu"><img src="../icon/soat.png" alt="*" width="16px" height="16px"/> <a href="/cron"> Rejalashtiruvchi (CRON)</a></div>';
 echo '<div class="title">Boshqalar</div>';
 
 echo '<div class="menu"><img src="../icon/isp.png" alt="*" width="16px" height="16px"/> <a href="/authtowebisp" target="_blank"> ISP Manager ga kirish WEB </a><font color="red">[NEW]</font></div>';
 echo '<div class="menu"><img src="../icon/isp.png" alt="*" width="16px" height="16px"/> <a href="/authtomobisp" target="_blank"> ISP Manager ga kirish WAP </a><font color="red">[NEW]</font></div>';
 echo '<div class="menu"><img src="../icon/phpmy.png" alt="*" width="16px" height="16px"/> <a href="/pma" target="_blank"> PhpMyAdmin [WAP]</a></div>';
 echo '<div class="menu"><img src="../icon/phpmyadmin.png" alt="*" width="16px" height="16px"/> <a href="http://thedc.uz/phpmyadmin" target="_blank"> PhpMyAdmin [WEB]</a></div>';
 echo '<div class="menu"><img src="../icon/round.png" alt="*" width="16px" height="16px"/> <a href="http://thedc.uz/roundcube" target="_blank"> RoundCube WebMail [WEB]</a></div>';
 }else{
if ($user[activ]==0) {$c1='<font color="red">faollashtirilmagan!</font> ()';}
if ($user[activ]==1) {$c1='<font color="red">faollashtirilmagan!</font>'; $c2='Faollashtirish uchun Hisobingizni '.$ustarif['price_day'].' rubl ga <a href="/pay">to`ldiring</a>';}
if ($user[activ]==2) {$c1='<font color="gren">Faol!</font>';}
if ($user[activ]==3) {$c1='<font color="red">uzilgan!</font>'; $c2='Shaxsiy hisobingizda mablag` yo`qligi sababli hisobingiz to`xtatildi. Shaxsiy hisobingiz haqida batafsil ma`lumotni mening hisobim panelida topishingiz mumkin.. Diqqat! 7 kundan ortiq vaqt davomida tarif to`lanmasa, <a href="http://uzxost.ml/info/rules/">Hosting qoidalari</a>ga ko`ra - sizning ma`lumotingiz qayta tiklanmasdan avtomatik ravishda yo`q qilinadi.</span><br/>Faollashtirish uchun Hisobingizni '.$ustarif['price_day'].' rubl ga <a href="/pay">to`ldiring</a>';}
if ($user[activ]==4) {$c1='<font color="red">bloklangan!</font>';}
if($user['money']>=$ustarif['price_day'] && $user[activ] <> 2){
    $ts='0';
echo '<div class="ok">Hisobga ishlov berilmoqda! Iltimos, faollashtirishni kuting!</div>';}else{$ts='1';}
echo '<div class="menu"><b>Hisobingizni hozirgi holati: '.$c1.'</b></div>';
if ($c2 && $ts) {
echo'<div class="menu"><h1 style="color: red;"><b>Diqqat!</b></h1>';
echo '<font color="red">'.$c2.'</font>';
echo '</div>';
}
 }
}else{
echo'<div class="menu"><h1 style="color: red;"><b>Diqqat!</b></h1>';
echo '<font color="red">Iltimos, hisobingizga kiring!</font>';
echo '</div>';
}
include_once($_SERVER["DOCUMENT_ROOT"]."/inc/foot.php");
 ?>
<?php
// baza ma'lumotlari!
DEFINE('DB_HOST','localhost');
DEFINE('DB_USER','thedcuz');
DEFINE('DB_PASS','D4t2E8g9');
DEFINE('DB_NAME','thedcuz');
?>
<?
    header('location: /');
?>
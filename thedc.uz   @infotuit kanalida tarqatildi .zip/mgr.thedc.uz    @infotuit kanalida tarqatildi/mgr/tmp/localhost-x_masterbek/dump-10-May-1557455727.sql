-- Wap PhpMyAdmin 211
-- http://master-land.net/phpmyadmin 
-- Generation Time: 2019-05-10 07:35
-- MySQL Server Version: 5.5.60-MariaDB
-- PHP Version: 7.2.17

-- Database: `masterbek_man`


-- --------------------------------------------------------
-- 
-- Table structure for table `hafta`
-- 

CREATE TABLE `hafta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ismi` varchar(36) NOT NULL,
  `comm` varchar(512) NOT NULL,
  `ajoyib` int(11) unsigned NOT NULL,
  `rasm` varchar(512) NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------
-- 
-- Dumping data for table `hafta`
-- 

INSERT INTO `hafta` VALUES ('4','Benzema','Jamoamizning hozirgi kunda yetakchisi','6','realfc.net/players/images/3597%20(1).png','0');

-- --------------------------------------------------------
-- 
-- Table structure for table `hafta_faoli`
-- 

CREATE TABLE `hafta_faoli` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL DEFAULT '',
  `onlayn_vaqti` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

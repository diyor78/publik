<?php
/*Ushbu kod: Temurbek (https://t.me/Temurriy) tomonidan yozilgan. Iltimos, mualliflik huquqi hurmat qilinsin!*/
ob_start();
define("API_KEY","1233299509:AAEPyeQXdjpDvbBBeH8OXC0DqwmuniuBzsw");
$admin = "1163829068";
$botname = "OsiyoBet_bot";
$tolovlaruz = "PulBoom";
$Temurriy = "admin";
$isbotgr = "pulboom";

$rasmiy_kanal = "@Strategiya_1X";
$arays = array($arays,$admin);

function addstat($id){
$check = file_get_contents("Temurriy.bot");
    $explode = explode("\n",$check);
    if(!in_array($id,$explode)){
        file_put_contents("Temurriy.bot","\n".$id,FILE_APPEND);
    }
}

function banstat($id){
    $check = file_get_contents("Temurriy.ban");
    $explode = explode("\n",$check);
    if(!in_array($id,$explode)){
        file_put_contents("Temurriy.ban","\n".$id,FILE_APPEND);
    }
}

function step($id,$value){
file_put_contents("Temurriy/$id.step","$value");
}

function stepbot($id,$value){
file_put_contents("Temurriybot/$id.step","$value");
}

function typing($chatid){ 
return Temurriy("sendChatAction",[
"chat_id"=>$chatid,
"action"=>"typing",
]);
}

function joinchat($id){
     global $message_id;
     global $rasmiy_kanal;
     $re = Temurriy("getChatMember",[
         "chat_id"=>"-1001420961388",
         "user_id"=>$id,
         ]);
$stat = $re->result->status;
$ret = Temurriy("getChatMember",[
         "chat_id"=>"-1001376116549",
         "user_id"=>$id,
         ]);
         $stats = $ret->result->status;
$rets = Temurriy("getChatMember",[
         "chat_id"=>"-1001351529863",
         "user_id"=>$id,
         ]);
$status = $rets->result->status;
         if((($stat=="creator" or $stat=="administrator" or $stat=="member") && ($stats=="creator" or $stats=="administrator" or $stats=="member") && ($status=="creator" or $status=="administrator" or $status=="member"))){
      return true;
         }else{
     Temurriy("sendMessage",[
         "chat_id"=>$id,
         "text"=>"<b>Quyidagi ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆ kanalimizga obuna boʻling. Botni keyin toʻliq ishlatishingiz mumkin!</b>",
         "parse_mode"=>"html",
         "reply_to_message_id"=>$message_id,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆","url"=>"https://t.me/joinchat/AAAAAFCOtYdjARUgJvFIow"],],
[["text"=>"♻️ Tastiqlash","callback_data"=>"result"],],
]
]),
]);  
return false;
}
}

function phonenumber($id){
     $phonenumber = file_get_contents("Temurriy/$id.contact");
      if($phonenumber==true){
      return true;
         }else{
     stepbot($id,"request_contact");
     Temurriy("sendMessage",[
    "chat_id"=>$id,
    "text"=>"<b>Salom, hurmatli foydalanuvchi!</b>\n<b>Pul ishlash ishonchli bo'lishi uchun, telefon raqamingizni yuboring:</b>",
    "parse_mode"=>"html",
    "reply_markup"=>json_encode([
      "resize_keyboard"=>true,
      "one_time_keyboard"=>true,
      "keyboard"=>[
        [["text"=>"📲 Telefon raqamni yuborish","request_contact"=>true],],
]
]),
]);  
return false;
}
}

function reyting(){
    $text = "<b>🏆 ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆ kanalining aksiyasida eng ko'p pul ishlayotgalar ro'yhati:</b>\n\n";
    $daten = [];
    $rev = [];
    $fayllar = glob("./Temurriy/*.*");
    foreach($fayllar as $file){
        if(mb_stripos($file,".pul")!==false){
        $value = file_get_contents($file);
        $id = str_replace(["./Temurriy/",".pul"],["",""],$file);
        $daten[$value] = $id;
        $rev[$id] = $value;
        }
        echo $file;
    }

    asort($rev);
    $reversed = array_reverse($rev);
    for($i=0;$i<10;$i+=1){
        $order = $i+1;
        $id = $daten["$reversed[$i]"];
        $text.= "<b>{$order}</b>. <a href='tg://user?id={$id}'>{$id}</a> - "."<code>".$reversed[$i]."</code>"." <b>soʻm</b>"."\n";
    }
    return $text;
}


function Temurriy($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$callbackdata = $update->callback_query->data;
$chatid = $message->chat->id;
$chat_id = $update->callback_query->message->chat->id;
$messageid = $message->message_id;
$id = $update->callback_query->id;
$fromid = $message->from->id;
$from_id = $update->callback_query->from->id;
$firstname = $message->from->first_name;
$first_name = $update->callback_query->from->first_name;
$lastname = $message->from->last_name;
$message_id = $update->callback_query->message->message_id;
$text = $message->text;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactuser = $contact->username;
$contactname = $contact->first_name;
$phonenumber = $contact->phone_number;
$messagereply = $message->reply_to_message->message_id;
$user = $message->from->username;
$users = $update->callback_query->from->username;
$inlineid = $update->inline_query->from->id;
$messagereply = $message->reply_to_message->message_id;
$soat = date("H:i:s",strtotime("2 hour")); 
$sana = date("d-M Y",strtotime("2 hour"));
$resultid = file_get_contents("Temurriy.bot");
$ban = file_get_contents("Temurriy/$chatid.ban");
$banid = file_get_contents("Temurriy/$chat_id.ban");
$sabab = file_get_contents("Temurriy/$chat_id.sabab");
$contactresult = file_get_contents("Temurriy/$chatid.contact");
if($sabab==true){
$sabab = $sabab;
}else{
$sabab = "Botdan faqat O'zbekiston fuqarolari foydalanishi mumkin!";
}
$referalsum = file_get_contents("Temurriy/referal.referalsum");
if($referalsum==true){
  $referalsum = $referalsum;
}else{
  $referalsum = "0";
}
$minimalsumma = file_get_contents("Temurriy/minimalsumma.minimal");
if($minimalsumma==true){
  $minimalsumma = $minimalsumma;
}else{
  $minimalsumma = "10000";
}
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
$sum = file_get_contents("Temurriy/$chatid.pul");
$sumcallback = file_get_contents("Temurriy/$chat_id.pul");
$jami = file_get_contents("Temurriy/summa.text");
$karta = file_get_contents("Temurriy/$chatid.karta");
$paynet = file_get_contents("Temurriy/$chatid.paynetraqam");
$qiwinomer = file_get_contents("Temurriy/$chatid.qiwinomer");
$referal = file_get_contents("Temurriy/$chatid.referal");
$referalcallback = file_get_contents("Temurriy/$chat_id.referal");
if(file_get_contents("Temurriy/$chatid.referal")){
}else{    file_put_contents("Temurriy/$chatid.referal","0");
}
$countreferal = file_get_contents("Temurriy/$chatid.countreferal");
if(file_get_contents("Temurriy/$chatid.countreferal")){
}else{    file_put_contents("Temurriy/$chatid.countreferal","0");
}
if(file_get_contents("Temurriy/$chatid.pul")){
}else{    file_put_contents("Temurriy/$chatid.pul","0");
}
$step = file_get_contents("Temurriy/$chatid.step");
$step = file_get_contents("Temurriybot/$chatid.step");
mkdir("Temurriy");
mkdir("Temurriybot");

$menu = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"♻️ Pul ishlash"],],
[["text"=>"💰 Hisobim"],["text"=>"🏆 Reyting"],],
[["text"=>"🤖 Bot Haqida"],],
]
]);

$panel = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🗣 Userlarga xabar yuborish"],],
[["text"=>"💳 Hisob tekshirish"],["text"=>"💰 Hisob toʻldirish"],],
[["text"=>"👥 Referal narxini o'zgartirish"],],
[["text"=>"✅ Bandan olish"],["text"=>"🚫 Ban berish"],],
[["text"=>"📤 Minimal pul yechish"],],
[["text"=>"⬅️ Ortga"],],
]
]);

$back = json_encode([
 "one_time_keyboard"=>true,
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"⬅️ Ortga"],],
]
]);

$startuz = json_encode([
"resize_keyboard"=>true,
"keyboard"=>[
[["text"=>"/start"],]
]
]);

if(($step=="request_contact") && ($ban==false) && (isset($phonenumber))){
$phonenumber = str_replace("+","","$phonenumber");
if(joinchat($chatid)=="true" && $ban==false){
if(strlen($phonenumber)==12){
if($contactid==$chatid){
addstat($chatid);
if(file_exists("Temurriy/".$fromid.".referalid")){
$referalid = file_get_contents("Temurriy/".$fromid.".referalid"); 
$channel = file_get_contents("Temurriy/".$fromid.".channel");
$conts = file_get_contents("Temurriy/".$fromid.".login");
if($channel=="true" and $conts=="false"){
if(joinchat($referalid)=="true"){
file_put_contents("Temurriy/".$fromid.".login","true");
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
$user = file_get_contents("Temurriy/".$referalid.".pul");
$referalsum = $referalsum / 2;
$user = $user + $referalsum;
file_put_contents("Temurriy/".$referalid.".pul","$user");
$firstname = str_replace(["<",">","/"],["","",""],$firstname);
Temurriy("sendMessage",[
"chat_id"=>$referalid,
"text"=>"<b>👏 Tabriklaymiz! Sizni do'stingiz</b> <a href='tg://user?id=$fromid'>$firstname</a> <b>botimizdan ro'yxatdan o'tdi va sizga $referalsum so'm taqdim etildi. Do'stingiz kanallarimizga a'zo bo'lsa, sizga yana $minimal sum taqdim etiladi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}
}
Temurriy("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"<b>Telefon raqamingiz saqlandi!</b>\n<b>Endi botdan to'liq foydalanishingiz mumkin!</b>",
    "parse_mode"=>"html",
    "reply_markup"=>$menu,
  ]);
file_put_contents("Temurriy/$chatid.contact","$phonenumber");
  unlink("Temurriybot/$chatid.step");
}else{
  addstat($chatid);
  Temurriy("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"<b>Faqat o'zingizni kontaktingizni yuboring:</b>",
    "parse_mode"=>"html",
    "reply_markup"=>json_encode([
      "resize_keyboard"=>true,
      "one_time_keyboard"=>true,
      "keyboard"=>[
        [["text"=>"📲 Telefon raqamni yuborish","request_contact"=>true],],
]
]),
]);
}
}else{
  banstat($chatid);
  Temurriy("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"<b>Kechirasiz! Botdan faqat O'zbekiston fuqarolari foydalanishi mumkin!</b>",
    "parse_mode"=>"html",
    "reply_to_message_id"=>$messageid,
    "reply_markup"=>json_encode([
    "remove_keyboard"=>true,
    ]),
  ]);
file_put_contents("Temurriy/$chatid.ban","ban");
unlink("Temurriybot/$chatid.step");
}
}
}

if($text=="/admin" and $chatid==$admin){
typing($chatid);
Temurriy('sendMessage',[
"chat_id"=>$chatid,
"text"=>"<b>Salom, Siz bot administratorisiz. Kerakli boʻlimni tanlang:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($text=="🗣 Userlarga xabar yuborish" and $chatid==$admin){
typing($chatid);
stepbot($chatid,"send_post");
      Temurriy("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"<b>Rasmli xabar matnini kiriting. Xabar turi markdown:</b>",
      "parse_mode"=>"html",
          "reply_markup"=>$panel,
          ]);
            }

     if($step=="send_post" and $chatid==$admin){
        $file_id = $message->photo[0]->file_id;
        $caption = $message->caption;
                $ok = Temurriy("sendPhoto",[
                  "chat_id"=>$chatid,
                  "photo"=>$file_id,
                  "caption"=>$caption,
                  "parse_mode"=>"markdown",
                ]);
                if($ok->ok){
                  Temurriy("sendPhoto",[
                    "chat_id"=>$chatid,
                    "photo"=>$file_id,
                      "caption"=>"$captionnnYaxshi, rasmni qabul qildim!nEndi tugmani na‘muna bo'yicha joylang.n
<pre>[Temurbek+https://t.me/bot_yaratuvchi]\n[Yangiliklar+https://t.me/UzBotMaster]</pre>",
"parse_mode"=>"html",
                      "disable_web_page_preview"=>true,
                    ]);
             file_put_contents("Temurriybot/$chatid.text","$file_id{set}$caption");
             stepbot($chatid,"xabar_tugma");
         }
     }
     
    if($step=="xabar_tugma" and $chatid==$admin){
      $xabar = Temurriy("sendMessage",[
        "chat_id"=>$chatid,
        "text"=>"Connections...",
      ])->result->message_id;
      Temurriy("deleteMessage",[
        "chat_id"=>$chat_id,
        "message_id"=>$xabar,
      ]);
   $usertext = file_get_contents("Temurriybot/$chatid.text");
   $fileid = explode("{set}",$usertext);
   $file_id = $fileid[0];
   $caption = $fileid[1];
       preg_match_all("|[(.*)]|U",$text,$ouvt);
$keyboard = [];
foreach($ouvt[1] as $ouut){
$ot = explode("+",$ouut);
array_push($keyboard,[["url"=>"$ot[1]", "text"=>"$ot[0]"],]);
}
$ok = Temurriy("sendPhoto",[
"chat_id"=>$chatid,
"photo"=>$file_id,
"caption"=>"Sizning rasmingiz ko‘rinishi:\n\n".$caption,
"parse_mode"=>"html",
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
if($ok->ok){
$userlar = file_get_contents("Temurriy.bot");
$count = substr_count($userlar,"n");
$count_member = count(file("Temurriy.bot"))-1;
  $ids = explode("n",$userlar);
  foreach ($ids as $line => $id) {
    $clear = Temurriy("sendPhoto",[
"chat_id"=>$id,
"photo"=>$file_id,
"caption"=>$caption,
"parse_mode"=>"markdown",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
unlink("Temurriybot/$chatid.step");
}

if($clear){
$userlar = file_get_contents("Temurriy.bot");
$count = substr_count($userlar,"n");
$count_member = count(file("Temurriy.bot"))-1;
  Temurriy("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"Xabar <b>$count_member</b> userlarga yuborildi!",
    "parse_mode"=>"html",
  ]);
}
}else{
  Temurriy("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"Tugmani kiritishda xato bor. Iltimos, qaytadan yuboring:",
  ]);
unlink("Temurriybot/$chatid.step");  
}
}

if($text=="💳 Hisob tekshirish" and $chatid==$admin){
typing($chatid);
stepbot($chatid,"result");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchini ID raqamini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="result" and $chatid==$admin){
typing($chatid);
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
$sum = file_get_contents("Temurriy/$text.pul");
$referal = file_get_contents("Temurriy/$text.referal");
$raqam = file_get_contents("Temurriy/$text.contact");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchi hisobi:</b> <code>$sum</code>\n<b>Foydalanuvchi referali:</b> <code>$referal</code>\n<b>Foydalanuvchi raqami:</b> <code>$raqam</code>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}
}

if($text=="💰 Hisob toʻldirish" and $chatid==$admin){
typing($chatid);
stepbot($chatid,"coin");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchi hisobini necha pulga toʻldirmoqchisiz:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="coin" and $chatid==$admin){
typing($chatid);
file_put_contents("Temurriy/$chatid.coin",$text);
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
stepbot($chatid,"pay");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchi ID raqamini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}
}

if($step=="pay" and $chatid==$admin){
typing($chatid);
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
$summa = file_get_contents("Temurriy/$chatid.coin");
$sum =  file_get_contents("Temurriy/$text.pul");
$jami = $sum + $summa;
file_put_contents("Temurriy/$text.pul","$jami");
Temurriy("sendMessage",[
   "chat_id"=>$text,
          "text"=>"💰 Hisobingiz: $summa so'mga to'ldirildi!nHozirgi hisobingiz: $jami",
]);
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchi balansi toʻldirildi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("Temurriybot/$chatid.step");
}
}

if($text=="👥 Referal narxini o'zgartirish" and $chatid==$admin){
typing($chatid);
stepbot($chatid,"referal");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Referal narxini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="referal" and $chatid==$admin){
typing($chatid);
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
file_put_contents("Temurriy/referal.referalsum","$text");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Referal taklif qilish narxi: $text so'mga o'zgardi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("Temurriybot/$chatid.step");
}
}

if($text=="✅ Bandan olish" and $chatid==$admin){
stepbot($chatid,"unban");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchini ID raqamini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="unban" and $chatid==$admin){
unlink("Temurriy/$text.ban");
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<a href='tg://user?id=$text'>Foydalanuvchi</a> <b>bandan olindi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("Temurriybot/$chatid.step");
}
}

if($text=="🚫 Ban berish" and $chatid==$admin){
stepbot($chatid,"sabab");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchini nima sababdan ban qilmoqchisiz:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="sabab" and $chatid==$admin){
file_put_contents("Temurriy/$chatid.sabab","$text");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Foydalanuvchini ID raqamini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
stepbot($chatid,"ban");
}

if($step=="ban" and $chatid==$admin){
banstat($text);
$sabab = file_get_contents("Temurriy/$chatid.sabab");
file_put_contents("Temurriy/$text.sabab","$sabab");
file_put_contents("Temurriy/$text.ban","ban");
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<a href='tg://user?id=$text'>Foydalanuvchi</a> <b>banlandi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("Temurriybot/$chatid.step");
Temurriy("sendMessage",[
"chat_id"=>$text,
"text"=>"<b>Hurmatli foydalanuvchi!</b>n<b>Siz botdan banlandingiz. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}
}

if($text=="📤 Minimal pul yechish" and $chatid==$admin){
typing($chatid);
stepbot($chatid,"minimalsumma");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal pul yechish narxini kiriting:</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($step=="minimalsumma" and $chatid==$admin){
typing($chatid);
if($text=="🗣 Userlarga xabar yuborish" or $text=="👥 Referal narxini o'zgartirish" or $text=="💳 Hisob tekshirish" or $text=="💰 Hisob toʻldirish" or $text=="✅ Bandan olish" or $text=="🚫 Ban berish" or $text=="📤 Minimal pul yechish" or $text=="⬅️ Ortga"){
}else{
file_put_contents("Temurriy/minimalsumma.minimal","$text");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<b>Minimal pul yechish narxi: $text so'mga o'zgardi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("Temurriybot/$chatid.step");
}
}

if($callbackdata=="/start" && $banid==false){
if(joinchat($from_id)=="true" && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
Temurriy("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"<b>Kerakli boʻlimni tanlang</b> 👇",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}
}

if($text=="♻️ Pul ishlash"){
if(joinchat($fromid)=="true" && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>✅ ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆  kanali eng zo'r aksiyasini boshladi!\n\n🗣️10 ta do'stingizni taklif eting va 2000 so'mni qo'lga kiriting!🤑\n\n👇 Boshlash uchun bosing:
https://t.me/$botname?start=$chatid</b> ",
"parse_mode"=>"html",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"↗️ Doʻstlarga yuborish","switch_inline_query"=>$chatid],],
]
]),
]);
}
}
}

if($text=="💰 Hisobim" && $ban==false){
if(joinchat($fromid)=="true" && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
if($sum==false){
$sum = "0";
}
if($referal==false){
$referal = "0";
}
if($countreferal==false){
$countreferal = "0";
}
if($jami==false){
$jami = "0";
}
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>" <b>☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆  kanalining aksiyasidan siz ishlagan pullar!</b>\n\n<b>💳Sizning hisobingiz:</b> <code>$sum</code>\n\n<b>🗣️Siz botga taklif qilgan a'zolar soni:</b> <code>$referal</code>\n\n<b>✔️Bot toʻlab bergan jami summa:</b> <code>$jami</code>\n\n<b>🤑Pul yechib olish uchun minimal summa:</b> <code>$minimalsumma</code> <b>soʻm</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📤 Pul yechish","callback_data"=>"production"],],
]
]),
]);
}
}
}

if($text=="⬅️ Ortga" && $ban==false){
if(joinchat($fromid)=="true" && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
addstat($chatid);
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>Kerakli boʻlimni tanlang</b> 👇",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
unlink("Temurriy/$chatid.paynet");
unlink("Temurriy/$chatid.click");
unlink("Temurriy/$chatid.qiwi");
unlink("Temurriy/$chatid.step");
unlink("Temurriybot/$chatid.step");
}
}
}

if((stripos($text,"/start")!==false) && ($ban==false)){
if(joinchat($fromid)=="true" && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
addstat($chatid);
$reply = Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>Quyidagi havolani doʻstlaringizga tarqatib pul ishlang!</b> 👇",
"parse_mode"=>"html",
"reply_markup"=>$menu,
])->result->message_id;
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>✅ ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆  kanali eng zo'r aksiyasini boshladi!

🗣️10 ta do'stingizni taklif eting va 2000 so'mni qo'lga kiriting!🤑

👇 Boshlash uchun bosing:
https://t.me/$botname?start=$chatid</b> ",
"parse_mode"=>"html",
"reply_to_message_id"=>$reply,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"↗️ Doʻstlarga yuborish","switch_inline_query"=>$chatid],],
]
]),
]);
unlink("Temurriy/$chatid.paynet");
unlink("Temurriy/$chatid.click");
unlink("Temurriy/$chatid.qiwi");
unlink("Temurriy/$chatid.step");
unlink("Temurriybot/$chatid.step");
}
}
}

if((stripos($text,"/start")!==false) && ($ban==false)){
$public = explode("*",$text);
$referalid = explode(" ",$text);
$referalid = $referalid[1];
if(strlen($referalid)>0){
$idref = "Temurriy/$referalid.id";
$idrefs = file_get_contents($idref);
$userlar = file_get_contents("Temurriy.bot");
$explode = explode("n",$userlar);
if(!in_array($chatid,$explode)){
file_put_contents("Temurriy.bot","n".$chatid,FILE_APPEND);
}
if($referalid==$chatid and $ban==false){
      Temurriy("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"☝️ <b>Hurmatli foydalanuvchi!</b>\n<b>Botga o'zingizni taklif qila olmaysiz!</b>",
      "parse_mode"=>"html",
      "reply_to_message_id"=>$messageid,
      ]);
      }else{
    if((stripos($userlar,"$chatid")!==false) and ($ban==false)){
      Temurriy("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"<b>Hurmatli foydalanuvchi!</b>\n<b>Siz do'stingizga referal bo'la olmaysiz, agar ushbu holat yana takrorlansa, siz botdan blocklanishingiz mumkin!</b>",
"parse_mode"=>"html",
"reply_to_message_id"=>$messageid,
]);
}else{
$id = "$chatidn";
$handle = fopen("$idref","a+");
fwrite($handle,$id);
fclose($handle);
file_put_contents("Temurriy/$fromid.referalid","$referalid");
file_put_contents("Temurriy/$fromid.channel","false");
file_put_contents("Temurriy/$fromid.login","false");
$firstname = str_replace(["<",">","/"],["","",""],$firstname);
      Temurriy("sendMessage",[
      "chat_id"=>$referalid,
"text"=>"<b>👏 Tabriklaymiz! Siz do'stingiz</b> <a href='tg://user?id=$chatid'>$firstname</a><b>ni botga taklif qildingiz!</b>\n<b>Do'stingiz kanalimizga a'zo bo'lmagunicha, biz sizga referal puli taqdim etmaymiz!</b>",
"parse_mode"=>"html",
]);
}
}
}
}

if($callbackdata=="result" and ($banid==false)){
addstat($from_id);
$from_id = $update->callback_query->from->id;
if((joinchat($from_id)=="true")  and ($banid==false)){
if(phonenumber($from_id)=="true"){
if($usernameid==true){
$result = "@$usernameid";
}else{
$result = "$first_name";
}
Temurriy("deleteMessage",[
"chat_id"=>$from_id,
"message_id"=>$update->callback_query->message->message_id,
]);
$reply = Temurriy("sendMessage",[
"chat_id"=>$from_id,
"text"=>"<b>Quyidagi havolani doʻstlaringizga tarqatib, pul ishlang!</b> 👇",
"parse_mode"=>"html",
"reply_markup"=>$menu,
])->result->message_id;
Temurriy("sendMessage",[
"chat_id"=>$from_id,
"text"=>"<b>✅ ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆  kanali eng zo'r aksiyasini boshladi!

🗣️10 ta do'stingizni taklif eting va 2000 so'mni qo'lga kiriting!🤑

👇 Boshlash uchun bosing:
https://t.me/$botname?start=$chatid</b> ",
"parse_mode"=>"html",
"reply_to_message_id"=>$reply,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"↗️ Doʻstlarga yuborish","switch_inline_query"=>$from_id],],
]
]),
]);
}
$time =  microtime(true);
$random  = rand(999999,3456789);
usleep($random);
$current  = microtime(true)-$time;
usleep($current);
if($referalsum==true){
if(file_exists("Temurriy/".$from_id.".referalid")){
$referalid = file_get_contents("Temurriy/".$from_id.".referalid");
if(joinchat($referalid)=="true"){
$is_user = file_get_contents("Temurriy/".$from_id.".channel");
$login = file_get_contents("Temurriy/".$from_id.".login");
if($is_user=="false" and $login=="false"){
$minimal = $referalsum / 2;
$user = file_get_contents("Temurriy/".$referalid.".pul");
$user = $user + $minimal;
file_put_contents("Temurriy/".$referalid.".pul","$user");
$referal = file_get_contents("Temurriy/".$referalid.".referal");
$referal = $referal + 1;
file_put_contents("Temurriy/".$referalid.".referal",$referal);
file_put_contents("Temurriy/".$from_id.".channel","true");
$firstname = str_replace(["<",">","/"],["","",""],$firstname);
Temurriy("sendMessage",[
"chat_id"=>$referalid,
"text"=>"<b>👏 Tabriklaymiz! Sizning do'stingiz</b> <a href='tg://user?id=".$from_id."'>".$first_name."</a> <b>kanallarga a'zo bo'ldi.</b>\n<b>Sizga ".$minimal." so'm taqdim etildi!</b>\n<b>Do'stingiz ro'yxatdan o'tsa, sizga yana ".$minimal." so'm taqdim etiladi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}
}
}
}else{
Temurriy("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Siz hali kanallarga aʼzo boʻlmadingiz!",
"show_alert"=>false,
]);
}
}

if($text=="/clean"){
file_put_contents("Temurriy/$fromid.pul","0");
}
  
if($callbackdata=="production" && $banid==false){
if(joinchat($from_id)=="true" && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
   if($sumcallback>=$minimalsumma){
   $hisob = file_get_contents("Temurriy/$chatid.pul");
    Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
]);
 Temurriy("sendMessage",[
    "chat_id"=>$chat_id,
          "text"=>"<b>💰 Pulingizni yechib olish uchun hamyonni tanlang!</b>",
          "parse_mode"=>"html",
          "reply_markup"=>json_encode([
              "inline_keyboard"=>[
                  [["text"=>"™️ Paynet","callback_data"=>"paynet"],],
                  [["text"=>"⬅️ Ortga","callback_data"=>"/start"],],
                  ]
                  ])
                  ]);
        }else{
          $som = $minimalsumma - $sumcallback;
          Temurriy("answerCallbackquery",[
              "callback_query_id"=>$id,
              "text"=>"☝️ Sizning hisobingizda mablag' yetarli emas!\nSizga yana mablag'ni yechib olish uchun $som so'm kerak!\nSizning hisobingizda: $sumcallback so'm mavjud!",
              "show_alert"=>true,
]);
      }
  }
  }
}

if($callbackdata=="paynet" && $banid==false){ 
if(joinchat($from_id) && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
if($sumcallback>=$minimalsumma){
  $paynet = file_get_contents("Temurriy/$chat_id.paynetraqam");
          Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
]);
 Temurriy("sendMessage",[
    "chat_id"=>$chat_id,
              "text"=>"❗️ Paynet qilmoqchi bo'lgan telefon raqamingizni kiriting!\nNa'muna: 998901234567",
          "reply_markup"=>json_encode([
             "one_time_keyboard"=>true,
"resize_keyboard"=>true,
    "keyboard"=>[
            [["text"=>"$paynet"],],
    [["text"=>"⬅️ Ortga"],],
                  ]
                  ])
                  ]);
          file_put_contents("Temurriy/$chat_id.paynet","raqam");
        }else{
          $som = $minimalsumma - $sumcallback;
          Temurriy("answerCallbackquery",[
              "callback_query_id"=>$id,
              "text"=>"☝️ Sizning hisobingizda mablag' yetarli emas!\nSizga yana mablag'ni yechib olish uchun $som so'm kerak!nSizning hisobingizda: $sumcallback so'm mavjud!",
              "show_alert"=>true,
]);
      }
  }
  }
}

if(file_get_contents("Temurriy/$chatid.paynet")=="raqam" && $ban==false){
if(strlen($text)==12){
if($sum>=$minimalsumma){
if(joinchat($fromid) && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
$hisob = file_get_contents("Temurriy/$chatid.pul");
file_put_contents("Temurriy/$chatid.paynet","summa");
              Temurriy("sendMessage",[
                  "chat_id"=>$chatid,
                  "text"=>"💳 To'lov miqdorini kiriting.\n💰 Sizning hisobingizda: $hisob so'm mavud!",
"reply_markup"=>$back,
]);
file_put_contents("Temurriy/$chatid.paynetraqam","$text");
}
}
}
    }else{
          Temurriy("sendMessage",[
              "chat_id"=>$chatid,
              "text"=>"❗️ Paynet qilmoqchi bo'lgan telefon raqamingizni kiriting!\nNa'muna: 998901234567",
              ]);
}
}

if(file_get_contents("Temurriy/$chatid.paynet")=="summa" and $sum>=$minimalsumma and file_get_contents("Temurriy/$chatid.paynet")!="raqam" && $ban==false){
    if($text=="/start" or $text=="⬅️ Ortga"){
        unlink("Temurriy/$chatid.paynet");
    }else{
        if(stripos($text,"998")!==false){
}else{
$hisob = file_get_contents("Temurriy/$chatid.pul");
if($text>=$minimalsumma and $hisob>=$text){
if(joinchat($fromid) && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
$puts = $hisob - $text;
$som = file_get_contents("Temurriy/$chatid.pul");
file_put_contents("Temurriy/$chatid.pul","$puts");
$jami = file_get_contents("Temurriy/summa.text");
$jami = $jami + $text;
file_put_contents("Temurriy/summa.text","$jami");
       $first_name = str_replace(["[","]","|"],["","",""],$firstname);
       Temurriy("sendMessage",[
           "chat_id"=>$chatid,
           "text"=>"⏰ So'rovlar yakunlandi!\nTo'lov 24 soat ichida amalga oshiriladi!\nTo'lov qilinganligi haqida sizga o'zimiz bot orqali xabar beramiz!",
"reply_markup"=>$menu,
]);
          Temurriy("sendMessage",[
              "chat_id"=>$admin,
              "text"=>"
💳 Foydalanuvchi pul yechib olmoqchi!

🗣 Foydalanuvchi: [$firstname](tg://user?id=$chatid)
🔢 Raqami: $paynet
💰 To'lov miqdori: $text so'm

✅ Zayafka $sana-$soat da keldi!",
          "parse_mode"=>"markdown",
          "reply_markup"=>json_encode([
                  "inline_keyboard"=>[
                      [["callback_data"=>"send|$chatid|$firstname","text"=>"💳 To'lov qabul qilindi"]],
[["callback_data"=>"no|$chatid|$firstname","text"=>"💳 To'lov bekor qilindi"]],
[["callback_data"=>"ban|$chatid|$firstname","text"=>"🚫 Ban berish"]],
                        ]
                       ])
                      ]);
          unlink("Temurriy/$chatid.paynet");
        }
      }
}else{
Temurriy("sendmessage",[
"chat_id"=>$chatid,
            "text"=>"💵 Sizning hisobingizda siz yechib olmoqchi bo'lgan pul mavjud emas!\nSiz faqat $hisob so'm pulni yechib olishingiz mumkin!",
          ]);
}
}
}
}

if((stripos($callbackdata,"send|")!==false) and ($from_id==$admin)){
    Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
]); 
       $ex = explode("|",$callbackdata);
       $id = $ex[1];
       $name = $ex[2];
       Temurriy("sendMessage",[
              "chat_id"=>$id,
              "text"=>"<b>Assalom-u alaykum, $name!</b>\n<b>Sizning botdan yechib olgan pulingiz to'lab berildi!\nIltimos, o'z fikringizni qoldiring!</b>",
              "parse_mode"=>"html",
               "reply_markup"=>json_encode([   
   "inline_keyboard"=>[
[["text"=>"Kanal","url"=> "https://telegram.me/$isbotgr"],],
]
]),
]);
}

if((stripos($callbackdata,"no|")!==false) and ($from_id==$admin)){
        Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
]); 
       $ex = explode("|",$callbackdata);
       $id = $ex[1];
       $name = $ex[2];
       Temurriy("sendMessage",[
              "chat_id"=>$id,
              "text"=>"<b>Assalom-u alaykum, $name!</b>n<b>Sizning botdan yechib olgan pulingiz bekor qilindi!</b>",
              "parse_mode"=>"html",
               "reply_markup"=>$menu,
]);
}

if((stripos($callbackdata,"ban|")!==false) and ($from_id==$admin)){
        Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
]); 
       $ex = explode("|",$callbackdata);
       $id = $ex[1];
       $name = $ex[2];
file_put_contents("Temurriy/$id.ban","ban");
Temurriy("sendMessage",[
"chat_id"=>$id,
"text"=>"<b>Hurmatli foydalanuvchi!</b>n<b>Siz botdan blocklandingiz. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}


   if($text=="/rmdir"){
       rmdir("Temurriy");
   }

$query = $update->inline_query->query;
if(mb_stripos($query,"$inlineid")!==false){
$user = $update->inline_query->from->username;
$firstname = $update->inline_query->from->first_name;
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
Temurriy("answerInlineQuery",[
"inline_query_id"=>$update->inline_query->id,
"cache_time"=>1,
"results"=>json_encode([[
"type"=>"article",
"id"=>base64_encode(1),
"title"=>"🎈 Unikal havola-taklifnoma",
"description"=>"$username doʻstingizdan unikal havola-taklifnoma",
"thumb_url"=>"https://yearling-truck.000webhostapp.com/demo/download.png",
"input_message_content"=>[
"disable_web_page_preview"=>true,
"parse_mode"=>"html",
"message_text"=>"<b>✅ ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆  kanali eng zo'r aksiyasini boshladi!\n\n🗣️10 ta do'stingizni taklif eting va 2000 so'mni qo'lga kiriting!🤑\n\n👇 Boshlash uchun bosing:
https://t.me/$botname?start=$chatid</b> "],
"reply_markup"=>[
"inline_keyboard"=>[
[["text"=>"🚀 Boshlash","url"=> "https://t.me/$botname?start=$inlineid"],],
]]
],
])
]);
}

if($text=="🏆 Reyting" && $ban==false){
if(joinchat($fromid) && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
$reyting = reyting();
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>$reyting,
"parse_mode"=>"html",
]);
}
}
}

if($text=="🤖 Bot Haqida" && $ban==false){
if(joinchat($fromid) && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
if($jami==false){
$jami = "0";
}
$userlar = file_get_contents("Temurriy.bot");
$count = substr_count($userlar,"\n");
$member = count(file("Temurriy.bot"))-1;
$banusers = file_get_contents("Temurriy.ban");
$bancount = substr_count($userlar,"\n");
$banmember = count(file("Temurriy.ban"))-1;

Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"
<b>⚜ ☆ 𝙎𝙝𝙚𝙮𝙭 (𝘽𝙀𝙏) ☆ kanalining pul ishlash boti haqida ma'lumot📩

👤Botimiz a'zolari soni</b>: <code> $member</code>
<b>🚫Qora roʻyxatdagi a'zolar soni: </b> </b><code>$banmember</code>
<b>🗣Siz botga taklif qilgan aʼzolar soni: </b> <code>$referal</code>
<b>💳Bot toʻlab bergan jami summa: </b> <code>$jami</code>

<b>❓Savol - botda qanday qilib pul ishlash mumkin?

❗Javob - botda pul ishlash juda oson, pul ishlash tugmasini bosing. Sizga berilgan unikal-havolani doʻstlaringizga yuboring. Doʻstingiz siz tarqatgan havola orqali botga kirib start bosishi va kanallarga a'zo bolib raqam jo'natishi bilan, biz sizni bot hisobingizga pul oʻtkazamiz.</b>

⌚Xozir - $sana-$soat",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"✔️ To'lovlar","url"=>"https://t.me/PulBoom"],],
[["text"=>"❓ Savolim bor","callback_data"=>"savol"],],
[["text"=>"❗ Xatolik topdim","callback_data"=>"xatolik"],],
[["text"=>"🤝 Taklifim bor","callback_data"=>"taklif"],],
]
]),
]);
}
}
}

if($callbackdata=="savol" && $banid==false){
if(joinchat($from_id) && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
file_put_contents("Temurriy/$chat_id.type","savol");
stepbot($chat_id,"savol");
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
Temurriy("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"🤓 Savolingizni batafsil yozib yuboring. Biz qisqa fursatlarda savolingizga javob berishga harakat qilamiz!",
"reply_markup"=>$back,
]);
}
}
}

if($callbackdata=="xatolik" && $banid==false){
if(joinchat($from_id) && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
file_put_contents("Temurriy/$chat_id.type","xatolik");
stepbot($chat_id,"savol");
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
Temurriy("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"😨 Qanday xatolik topdingiz? Iltimos, xatolikni batafsil yozib yuboring!",
"reply_markup"=>$back,
]);
}
}
}

if($callbackdata=="taklif" && $banid==false){
if(joinchat($from_id) && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
file_put_contents("Temurriy/$chat_id.type","taklif");
stepbot($chat_id,"savol");
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
Temurriy("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"👍 Ajoyib! G'oyangizni batafsil yozib yuboring!",
"reply_markup"=>$back,
]);
}
}
}

if($step=="savol" && $ban==false){
if(joinchat($fromid) && ($ban==false)){
if(phonenumber($fromid)=="true" && ($ban==false)){
$type = file_get_contents("Temurriy/$chatid.type");
$username = str_replace("@","",$username);
if($text=="/start" or $text=="⬅️ Ortga"){
unlink("Temurriybot/$chatid.step");
}else{ 
file_put_contents("Temurriy/$chatid.sms","$text");
file_put_contents("Temurriy/$chatid.messagetype","$type");
Temurriy("sendMessage",[
"chat_id"=>$admin,
"text"=>"<a href='tg://user?id=$fromid'>$firstname</a> <b>foydalanuvchidan yangi xabar keldi:</b>\n<b>Xabar turi:</b> $type\n<b>Xabar matni:</b> <code>$text</code>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"🗣 Bog'lanish","url"=>"https://t.me/$username"],],
[["text"=>"✅ Javob berish","callback_data"=>"reply|$chatid|$firstname"],],
]
]),
]);
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Xabaringiz yuborildi, fikr va mulohazalaringiz uchun rahmat!",
"reply_to_message_id"=>$messageid,
"reply_markup"=>$menu,
]);
unlink("Temurriybot/$chatid.step");
}
}
}
}

if((stripos($callbackdata,"reply|")!==false) && ($from_id==$admin)){
if(joinchat($from_id)=="true"){
if(phonenumber($from_id)=="true"){
  typing($chat_id);
  Temurriy("deleteMessage",[
    "chat_id"=>$chat_id,
    "message_id"=>$message_id,
  ]);
       $ex = explode("|",$callbackdata);
       $id = $ex[1];
       $name = $ex[2];
       file_put_contents("Temurriy/$chat_id.xabar",$id);
             Temurriy("sendMessage",[
              "chat_id"=>$chat_id,
              "text"=>"<b>Xabaringizni kiriting:</b>",
              "parse_mode"=>"html",
               "reply_markup"=>$back,
]);
             stepbot($chat_id,"reply");
           }
         }
       }

       if($step=="reply" && $chatid==$admin){
        $send = file_get_contents("Temurriy/$chatid.xabar");
        $savol = file_get_contents("Temurriy/$send.sms");
        if($text=="/start" or $text=="⬅️ Ortga"){
       unlink("Temurriybot/$chatid.step");
       }else{ 
       Temurriy("sendMessage",[
        "chat_id"=>$send,
        "text"=>"<b>Sizning savolingiz: $savol</b>\n\n<b>Javob: $text</b>",
        "parse_mode"=>"html",
        "reply_markup"=>$menu,
      ]);
       Temurriy("sendMessage",[
              "chat_id"=>$admin,
              "text"=>"<a href='tg://user?id=$send'>Foydalanuvchi</a><b>ga xabaringiz yuborildi!</b>",
              "parse_mode"=>"html",
               "reply_markup"=>$menu,
]);
file_put_contents("Temurriy/$send.javob",$text);              unlink("Temurriybot/$chatid.step");
     }
}

if($callbackdata=="xabarim" && $banid==false){
if(joinchat($from_id)=="true" && ($banid==false)){
if(phonenumber($from_id)=="true" && ($banid==false)){
$type = file_get_contents("Temurriy/$chat_id.messagetype");
$xabar = file_get_contents("Temurriy/$chat_id.sms");
$javob = file_get_contents("Temurriy/$chat_id.javob");
if($javob==false){
$javob = "savolingizga hali javob berilmadi!";
}
if($xabar==true){
Temurriy("answerCallbackquery",[
"callback_query_id"=>$id,
"text"=>"Xabar turi: $type\n\nXabaringiz: $xabar\n\nJavob: $javob",
"show_alert"=>true,
]);
}else{
Temurriy("answerCallbackquery",[
"callback_query_id"=>$id,
"text"=>"Siz hali xabar yubormagansiz...",
"show_alert"=>false,
]);
}
}
}
}

if($ban==true){
Temurriy("deleteMessage",[
"chat_id"=>$chatid,
"message_id"=>$messageid,
]);
Temurriy("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>Hurmatli foydalanuvchi!</b>\n<b>Siz botdan banlangansiz. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}

if($banid==true){
Temurriy("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
Temurriy("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"<b>Hurmatli foydalanuvchi!</b>\n<b>Siz botdan banlangansiz. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}

if($callbackdata=="sabab"){
Temurriy("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>$sabab,
"show_alert"=>true,
]);
}